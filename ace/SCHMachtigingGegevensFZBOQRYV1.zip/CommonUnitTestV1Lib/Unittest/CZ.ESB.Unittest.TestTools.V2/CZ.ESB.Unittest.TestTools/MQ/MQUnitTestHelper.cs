﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CZ.ESB.Unittest.TestTools.MQ
{
    public class MQUnitTestHelper
    {
        public static void TestAll()
        {
            NotAvailable();
            QueueManagerNotAvailable();
        }

        public static void NotAvailable()
        {
            try
            {
                string data = MQConnect.ReadStringFromQueue("THIS.QUEUE.DOES.NOT.EXIST");
            }
            catch (Exception ex)
            {
                Assert.AreEqual("MQRC_UNKNOWN_OBJECT_NAME", ex.Message);
            }
        }

        public static void QueueManagerNotAvailable()
        {
            try
            {
                string data = MQConnect.ReadStringFromQueue("NOTAKNOWNQM","THIS.QUEUE.DOES.NOT.EXIST");
            }
            catch (Exception ex)
            {
               
                Assert.AreEqual("MQRC_Q_MGR_NAME_ERROR", ex.Message);
            }
        }
    }
}
