﻿using CZ.ESB.Unittest.TestTools.Base;
using System.Collections.Generic;
using System.Text;
using System.IO;
using IBM.WMQ;
using System.Diagnostics;
using CZ.ESB.Unittest.TestTools.Properties;
using System;

namespace CZ.ESB.Unittest.TestTools.MQ
{
    public class MQNewQueue
    {
        private MQQueueManager queueManager;
        private MQQueue queue;

        public enum QueueType
        {
            LOCAL,
            ALIAS
        }

       
        public string BackoutQueue { get; private set; }

        public string Persistancy { get; private set; }

        static public List<MQNewQueue> mqNewQueues = new List<MQNewQueue>();

        public string QueueManager { get; private set; }

        public string NewQueue { get; private set; }

        public QueueType TypeQueue { get; private set; }

        public string BaseQueue { get; private set; }
        public long MessageSize { get; private set; }

        public static string GetPersistancyValues(bool persistant)
        {
            return persistant ? "YES" : "NO";
        }

        public static MQNewQueue Connect(string newQueue)
        {
            return Connect(null, newQueue, QueueType.LOCAL, null, null, false, 0);
        }

        public static MQNewQueue Connect(string newQueue, long messageSizeInBytes)
        {
            return Connect(null, newQueue, QueueType.LOCAL, null, null, false, messageSizeInBytes);
        }

        public static MQNewQueue Connect(string newQueue, bool persistant)
        {
            return Connect(null, newQueue, QueueType.LOCAL, null, null, persistant, 0);
        }

        public static MQNewQueue Connect(string newQueue, QueueType typeQueue)
        {
            return Connect(null, newQueue, typeQueue, null, null, false, 0);
        }
        public static MQNewQueue Connect(string newQueue, QueueType typeQueue, string relatedQueue)
        {
            if (typeQueue == QueueType.ALIAS)
            {
                return Connect(null, newQueue, typeQueue, relatedQueue, null, false, 0);
            }
            else
            {
                return Connect(null, newQueue, typeQueue, null, relatedQueue, false, 0);
            }
        }

        public static MQNewQueue Connect(string newQueue, string relatedQueue, bool persistant)
        {
            return Connect(null, newQueue, QueueType.LOCAL, null, relatedQueue, persistant, 0);
        }
        public static MQNewQueue Connect(string queueManager, string newQueue, QueueType typeQueue)
        {
            return Connect(queueManager, newQueue, typeQueue, null, null, false, 0);
        }

        public static MQNewQueue Connect(string newQueue, string baseQueue)
        {
            return Connect(null, newQueue, QueueType.ALIAS, baseQueue, null, false, 0);
        }

        public static MQNewQueue Connect(string queueManager, string newQueue, string baseQueue)
        {
            return Connect(queueManager, newQueue, QueueType.ALIAS, baseQueue, null, false, 0);
        }

        private static MQNewQueue Connect(string queueManager, string newQueue, QueueType typeQueue, string baseQueue, string backoutQueue, Boolean persistance, long messageSizeInBytes)
        {
            MQNewQueue mqNewQueue = new MQNewQueue();
            if (queueManager == null)
            {
                mqNewQueue.QueueManager = GetQueueManager();
            }
            else
            {
                mqNewQueue.QueueManager = queueManager;
            }
            mqNewQueue.NewQueue = newQueue;
            mqNewQueue.TypeQueue = typeQueue;
            if (baseQueue == null)
            {
                mqNewQueue.BaseQueue =   "\'\'";
            }
            else
            {
                mqNewQueue.BaseQueue = baseQueue;
            }
            if (backoutQueue == null)
            {
                mqNewQueue.BackoutQueue = "\'\'";
            }
            else
            {
                mqNewQueue.BackoutQueue = backoutQueue;
            }
            if (persistance == null)
            {
                mqNewQueue.Persistancy = GetPersistancyValues(false);
            }
            else
            {
                mqNewQueue.Persistancy = GetPersistancyValues(persistance);
            }
            if (messageSizeInBytes == 0)
            {
                mqNewQueue.MessageSize = 4194304;
            }
            else
            {
                mqNewQueue.MessageSize = messageSizeInBytes;
            }
             
            mqNewQueues.Add(mqNewQueue);

            return mqNewQueue;
        }

        public static void ProcessAll()
        {
            foreach (MQNewQueue mqNewQueue in mqNewQueues)
            {
                mqNewQueue.Process();
                //builds falen regelmatig op UnauthorizedAccessException op CreateLocalQueue.bat, waarschijnlijk door te snel aanroepen in deze loop, met sleep oplossen....
                System.Threading.Thread.Sleep(3000);
            }
        }

        public void Process()
        {
            if (TypeQueue != QueueType.ALIAS) {
                CreateNewLocalQueue();
              }
            else { CreateNewAliasQueue(); }
        }

        private void CreateNewLocalQueue()
        {
            string script = Resources.CreateLocalQueue;
            const string fileName = "CreateLocalQueue.bat";
            File.AppendAllText(fileName, AddLines(script));
            string arguments = $"{QueueManager} {NewQueue} {BackoutQueue} {Persistancy} {MessageSize}";
            //start a process and hook up the in/output
            var proces = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = fileName,
                    Arguments = arguments,
                    CreateNoWindow = false,
                    ErrorDialog = true,
                    RedirectStandardError = false,
                    RedirectStandardOutput = false,
                    UseShellExecute = true
                },
                EnableRaisingEvents = true
            };

            //store the errors in a stringbuilder
            var errorBuilder = new StringBuilder();
            proces.ErrorDataReceived += (sender, args) =>
            {
                if (args != null && args.Data != null)
                {
                    errorBuilder.AppendLine(args.Data);
                }
            };

            //store the errors in a stringbuilder
            var outputBuilder = new StringBuilder();
            proces.OutputDataReceived += (sender, args) =>
            {
                if (args != null && args.Data != null)
                {
                    outputBuilder.AppendLine(args.Data);
                }
            };

            proces.Start();
            proces.WaitForExit();

            OutputMessageReceived?.Invoke(outputBuilder.ToString());
            ErrorMessageReceived?.Invoke(errorBuilder.ToString());
            
            proces.Close();
            
            File.Delete(fileName);
        }

        private void CreateNewAliasQueue()
        {
            string script = Resources.CreateAliasQueue;
            const string fileName = "CreateAliasQueue.bat";
            File.AppendAllText(fileName, AddLines(script));
            string arguments = $"{QueueManager} {NewQueue} {BaseQueue}";
            //start a process and hook up the in/output
            var proces = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = fileName,
                    Arguments = arguments,
                    CreateNoWindow = false,
                    ErrorDialog = true,
                    RedirectStandardError = false,
                    RedirectStandardOutput = false,
                    UseShellExecute = true
                },
                EnableRaisingEvents = true
            };

            //store the errors in a stringbuilder
            var errorBuilder = new StringBuilder();
            proces.ErrorDataReceived += (sender, args) =>
            {
                if (args != null && args.Data != null)
                {
                    errorBuilder.AppendLine(args.Data);
                }
            };

            //store the errors in a stringbuilder
            var outputBuilder = new StringBuilder();
            proces.OutputDataReceived += (sender, args) =>
            {
                if (args != null && args.Data != null)
                {
                    outputBuilder.AppendLine(args.Data);
                }
            };

            proces.Start();
            proces.WaitForExit();

            OutputMessageReceived?.Invoke(outputBuilder.ToString());
            ErrorMessageReceived?.Invoke(errorBuilder.ToString());

            proces.Close();

            File.Delete(fileName);
        }

        public static event OutputMessageReceivedHandler OutputMessageReceived ;
        public static event ErrorMessageReceivedHandler ErrorMessageReceived ;

        public delegate void ErrorMessageReceivedHandler(string message);
        public delegate void OutputMessageReceivedHandler(string message);


        private static string GetQueueManager()
        {
            return UnitTestHelper.ReadConfigurationSetting("QueueManager");
        }

        public static string AddLines(string msg)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(msg);
            if (pause)
            {
                sb.AppendLine("pause");
            }

            return sb.ToString();
        }

        public static bool pause { get; set; }
        /// <summary>
        /// Only run on VDI!
        /// </summary>
        public static void PauseAfterScript()
        {
            pause = true;
        }
    }
}
