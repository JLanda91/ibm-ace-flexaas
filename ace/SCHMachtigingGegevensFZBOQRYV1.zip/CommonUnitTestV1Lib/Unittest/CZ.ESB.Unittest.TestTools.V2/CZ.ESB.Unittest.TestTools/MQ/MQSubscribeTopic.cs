﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using IBM.WMQ;

namespace CZ.ESB.Unittest.TestTools.MQ
{
    public class MQSubscribeTopic : MQPubSub
    {
        public const string SubscribeToAll = "#";

        protected int pollingAttempts = 100;
        protected int pollingInterval = 100;
        protected MQTopic topicForGet;

        public void ChangePollingInterval(int ms)
        {
            pollingInterval = ms;
        }

        public void ChangePollingAttempts(int attempts)
        {
            pollingAttempts = attempts;
        }

        public static MQMessage SubscribeToQueueAndReadMessage(string topicString, string topicName, bool waitForAnswer = true)
        {
            MQSubscribeTopic subscribeTopic = Connect<MQSubscribeTopic>();
            subscribeTopic.Subscribe(topicName, topicString);
            return subscribeTopic.Get(waitForAnswer);
        }

        public static string SubscribeToQueueAndReadString(string topicString, string topicName, bool waitForAnswer = true)
        {
            MQMessage message = SubscribeToQueueAndReadMessage(topicString, topicName, waitForAnswer);
            return MQMessageHelper.ReadMessageString(message);
        }

        public void Subscribe(string topicName, string topicString)
        {
            topicForGet = queueManager.AccessTopic(topicString, topicName, MQC.MQTOPIC_OPEN_AS_SUBSCRIPTION, openOptionsForGet);
        }

        public MQMessage Get(bool waitForAnswer)
        {
            //TOPICOBJ('VER/CASUS/COM/SYSV1') TOPICSTR('/STARTCASUS/#'

            
            MQMessage msg = null;
            this.waitForAnswer = waitForAnswer;
            currentReads = 0;
            if (!waitForAnswer)
            {
                return Get();
            }
            else
            {
                msg = Get();
                while (!messageAvailable && currentReads <= pollingAttempts)
                {
                    Thread.Sleep(pollingInterval);
                    msg = Get();
                    currentReads++;
                }

                if (currentReads >= pollingAttempts)
                {
                    throw new TimeoutException();
                }
            }

            return msg;
        }

        private MQMessage Get()
        {
            try
            {

                var messageForGet = new MQMessage();

                topicForGet.Get(messageForGet);
                messageAvailable = true;

                return messageForGet;
            }
            catch (Exception ex)
            {
                if (waitForAnswer && ex.Message == "MQRC_NO_MSG_AVAILABLE")
                {
                    messageAvailable = false;
                    return null;
                }
                else
                {
                    throw;
                }
            }
        }
    }
}
