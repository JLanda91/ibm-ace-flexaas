﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CZ.ESB.Unittest.TestTools.MQ
{
    public class Id
    {
        public string ValueAsString { get; set; }
        public byte[] ValueAsBytes { get; set; }
    }
}
