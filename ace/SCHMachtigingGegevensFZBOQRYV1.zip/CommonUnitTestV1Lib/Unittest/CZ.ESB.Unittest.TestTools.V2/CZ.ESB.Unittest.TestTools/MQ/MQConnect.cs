﻿using System;
using System.Configuration;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using CZ.ESB.Unittest.TestTools.Base;
using CZ.ESB.Unittest.TestTools.FILE;
using IBM.WMQ;

namespace CZ.ESB.Unittest.TestTools.MQ
{
    public class MQConnect 
    {
        MQQueueManager queueManager;
        MQQueue queue;
        MQMessage queueMessage;
        MQPutMessageOptions queuePutMessageOptions;
        MQGetMessageOptions queueGetMessageOptions;

        public string QueueManager { get; private set; }
        public string Queue { get; private set; }

        public string ReplyToQueueManager { get; private set; }
        public string ReplyToQueue { get; private set; }
        public string ApplicationIdData { get; set; }

        public byte[] MessageId { get; set; }

        public byte[] CorrelationId { get; set; }

        private bool waitForAnswer = false;
        private bool messageAvailable = true;
        private int pollingAttempts = 100;
        private int pollingInterval = 100;
        private int currentReads = 0;

        public static MQConnect Connect(string queue)
        {
            return Connect(null, queue);
        }

        
        public static MQConnect Connect(string queueManager, string queue)
        {
            MQConnect mqConnect = new MQConnect();
            if (queueManager == null)
            {
                mqConnect.QueueManager = GetQueueManager();
            }
            else
            {
                mqConnect.QueueManager = queueManager;
            }
            mqConnect.Queue = queue;
            return mqConnect;
        }

        public static void PutFileRequestOnQueue(string requestQueue, string replyQueue, string fileName)
        {
            PutFileRequestOnQueue(null, requestQueue, replyQueue, fileName, null);
        }

        public static void PutFileRequestOnQueue(string requestQueue, string replyQueue, string fileName, string methodName)
        {
            PutFileRequestOnQueue(null, requestQueue, replyQueue, fileName, methodName);
        }

        public static void PutFileRequestOnQueue(string queueManager, string requestQueue, string replyQueue, string fileName, string methodName)
        {
            string content = Files.ReadString(Files.GetFullFilePath(fileName));

            PutStringRequestOnQueue(queueManager, requestQueue, replyQueue, content, methodName);
        }

        public static void PutFileOnQueue(string queue, string fileName)
        {
            PutFileOnQueue(null, queue, fileName);
        }

        public static void PutFileWithBytesOnQueue(string queue, string fileName)
        {
            byte[] content = Files.ReadBytes(Files.GetFullFilePath(fileName));

            PutBytesMessageOnQueue(null, queue, content);
        }

        public static void PutFileOnQueue(string queueManager, string queue, string fileName)
        {
            string content = Files.ReadString(Files.GetFullFilePath(fileName));

            PutStringMessageOnQueue(queueManager, queue, content);
        }

        public static void PutFileWithBytesOnQueue(string queueManager, string queue, string fileName)
        {
            byte[] content = Files.ReadBytes(Files.GetFullFilePath(fileName));

            PutBytesMessageOnQueue(queueManager, queue, content);
        }

        public static void PutBytesOnQueue(string queueManager, string queue, string fileName)
        {
            byte[] content = Files.ReadBytes(Files.GetFullFilePath(fileName));

            PutBytesMessageOnQueue(queueManager, queue, content);
        }


        public static void PutStringMessageOnQueue(string queue, string message)
        {

            PutStringMessageOnQueue(null, queue, message);
        }

        public static void PutStringMessageOnQueue(string queueManager, string queue, string message)
        {

            MQConnect mq = Connect(queueManager, queue);

            mq.CorrelationId = CorrelationIdGenerator.Generate().ValueAsBytes;
            mq.MessageId = MessageIdGenerator.Generate().ValueAsBytes;

            mq.SendMessage(message);
        }

        public static void PutBytesMessageOnQueue(string queue, byte[] message)
        {

            PutBytesMessageOnQueue(null, queue, message);
        }

        public static void PutBytesMessageOnQueue(string queueManager, string queue, byte[] message)
        {

            MQConnect mq = Connect(queueManager, queue);

            mq.CorrelationId = CorrelationIdGenerator.Generate().ValueAsBytes;
            mq.MessageId = MessageIdGenerator.Generate().ValueAsBytes;

            mq.SendMessage(message);
        }

        public static void PutStringRequestOnQueue(string requestQueue, string replyQueue, string message)
        {

            PutStringRequestOnQueue(null, requestQueue, replyQueue, message, null);
        }

        public static void PutStringRequestOnQueue(string requestQueue, string replyQueue, string message, string methodName)
        {

            PutStringRequestOnQueue(null, requestQueue, replyQueue, message, methodName);
        }

        public static void PutStringRequestOnQueue(string queueManager, string requestQueue, string replyQueue, string message, string methodName)
        {

            MQConnect mq = Connect(queueManager, requestQueue);

            mq.SetReplyToQueue(replyQueue);

            mq.SetCorrelationId(CorrelationIdGenerator.Generate().ValueAsBytes);
            mq.SetMessageId(MessageIdGenerator.Generate().ValueAsBytes);
            mq.SetApplicationIdData(methodName);

            mq.SendMessage(message);
        }

        public static MQMessage ReadMessageFromQueue(string queue)
        {
            return ReadMessageFromQueue(null, queue);
        }

        public static MQMessage ReadMessageFromQueue(string queueManager, string queue)
        {
            MQConnect mq = Connect(queueManager, queue);

            return mq.Get(true);
        }

        public static string ReadStringFromQueue(string queue)
        {
            return ReadStringFromQueue(null, queue);
        }

        public static string ReadStringFromQueue(string queueManager, string queue)
        {
            MQConnect mq = Connect(queueManager, queue);

            mq.Get(true);
            return mq.ReadString();
        }


        public static string ReadQueueAndReplyWithFile(string readQueue, string fileName)
        {
            return ReadQueueAndReplyWithMessage(GetQueueManager(), readQueue, Files.ReadString(fileName));
        }

        public static string ReadQueueAndReplyWithMessage(string readQueue, string replyMessage)
        {
            return ReadQueueAndReplyWithMessage(GetQueueManager(), readQueue, replyMessage);
        }

        public static string ReadQueueAndReplyWithMessage(string queueManager, string readQueue, string replyMessage)
        {
            MQConnect mqRead = Connect(queueManager, readQueue);
            var readMessage = mqRead.Get(true);

            MQConnect mqReply = Connect(readMessage.ReplyToQueueManagerName, readMessage.ReplyToQueueName);
            mqReply.SetCorrelationId(readMessage.MessageId);
            mqReply.SendMessage(replyMessage);

            return readMessage.ReadString(readMessage.MessageLength);
        }

        public static int GetQueueDepth(string queueName)
        {
            MQConnect mq = MQConnect.Connect(queueName);
            mq.ConnectToInquireMq();

            if(mq.queue.QueueType == MQC.MQQT_ALIAS)
            {
                return GetQueueDepth(mq.queue.BaseQueueName);
            }
            else
            {
                return mq.queue.CurrentDepth;
            }
        }


        private static string GetQueueManager()
        {
            return UnitTestHelper.ReadConfigurationSetting("QueueManager");
        }

        public void SetApplicationIdData(string applicationIdData)
        {
            ApplicationIdData = applicationIdData;
        }

        public void SetMessageId(byte[] messageId)
        {
            MessageId = messageId;
        }

        public void SetCorrelationId(byte[] correlationId)
        {
            CorrelationId = correlationId;
        }

        public void SetReplyToQueue(string queue)
        {
            ReplyToQueue = queue;
        }

        public void SetReplyToQueue(string queueManager, string queue)
        {
            ReplyToQueueManager = queueManager;
            ReplyToQueue = queue;
        }

        public void SendMessage(string content)
        {
            byte[] dataInBytes = Encoding.Default.GetBytes(content);

            dataInBytes = Encoding.Convert(Encoding.Default, Encoding.UTF8, dataInBytes);

            SendMessage(dataInBytes);

        }

        public void SendMessage(byte[] content)
        {
            ConnectToPutMq();
            BuildMessageData();

            queueMessage.Write(content);

            if (queuePutMessageOptions == null)
            {
                queuePutMessageOptions = new MQPutMessageOptions();
            }

            queuePutMessageOptions.Options += MQC.MQPMO_SET_IDENTITY_CONTEXT;
            queue.Put(queueMessage, queuePutMessageOptions);
        }

        public void SendMessage(MQMessage message)
        {
            ConnectToPutMq();
            queue.Put(message);
        }

        private void ConnectToInquireMq()
        {
            queueManager = new MQQueueManager(QueueManager);
            queue = queueManager.AccessQueue(Queue, MQC.MQOO_INQUIRE);
        }

        private void ConnectToBrowseMq()
        {
            queueManager = new MQQueueManager(QueueManager);
            queue = queueManager.AccessQueue(Queue, MQC.MQOO_SET);
        }

        private void ConnectToPutMq()
        {
            queueManager = new MQQueueManager(QueueManager);
            queue = queueManager.AccessQueue(Queue, MQC.MQOO_OUTPUT + MQC.MQOO_SET_IDENTITY_CONTEXT + MQC.MQOO_FAIL_IF_QUIESCING);

        }

        private void ConnectToGetMq()
        {
            queueManager = new MQQueueManager(QueueManager);

            queue = queueManager.AccessQueue(Queue, MQC.MQOO_INPUT_AS_Q_DEF + MQC.MQOO_FAIL_IF_QUIESCING);

        }

        public MQMessage Get()
        {
            try
            {
                ConnectToGetMq();
                queueGetMessageOptions = new MQGetMessageOptions();
                queueMessage = new MQMessage();
                queueMessage.Format = MQC.MQFMT_STRING;

                queue.Get(queueMessage, queueGetMessageOptions);

                MessageId = queueMessage.MessageId;
                CorrelationId = queueMessage.CorrelationId;
                ReplyToQueue = queueMessage.ReplyToQueueName;
                ReplyToQueueManager = queueMessage.ReplyToQueueManagerName;
                messageAvailable = true;

                return queueMessage;
            }
            catch (Exception ex)
            {
                if (waitForAnswer && ex.Message == "MQRC_NO_MSG_AVAILABLE")
                {
                    messageAvailable = false;
                }
                else
                {
                    throw;
                }
            }

            return null;
        }

        public void ChangePollingInterval(int ms)
        {
            pollingInterval = ms;
        }

        public void ChangePollingAttempts(int attempts)
        {
            pollingAttempts = attempts;
        }

        public void AllowPut(bool allow)
        {
            ConnectToBrowseMq();
            queue.InhibitPut = allow ? MQC.MQQA_PUT_ALLOWED : MQC.MQQA_PUT_INHIBITED;
        }

        public void AllowGet(bool allow)
        {
            ConnectToBrowseMq();
            queue.InhibitGet = allow ? MQC.MQQA_GET_ALLOWED : MQC.MQQA_GET_INHIBITED;
        }

        public static void EnableQueue(string queue, bool enable)
        {
            Connect(queue).AllowGet(enable);
            Connect(queue).AllowPut(enable);
        }

        public static void Clean(string queue)
        {
            Clean(GetQueueManager(), queue);
        }

        public static void Clean(string queueManager, string queue)
        {
            try
            {
                MQConnect mq = Connect(queueManager, queue);
                while (true)
                {
                    mq.Get();
                    mq.ReadString();
                }
            }
            catch
            {
                //swallow the exceptions
            }
        }

        public MQMessage Get(bool waitForAnswer)
        {
            MQMessage msg = null;
            this.waitForAnswer = waitForAnswer;
            currentReads = 0;
            if (!waitForAnswer)
            {
                msg = Get();
            }
            else
            {
                msg = Get();
                while (!messageAvailable && currentReads <= pollingAttempts)
                {
                    Thread.Sleep(pollingInterval);
                    msg = Get();
                    currentReads++;
                }

                if (currentReads >= pollingAttempts)
                {
                    throw new TimeoutException();
                }
            }

            return msg;
        }

        public string ReadString()
        {
            return queueMessage.ReadString(queueMessage.MessageLength);
        }

        public byte[] ReadBytes()
        {
            return queueMessage.ReadBytes(queueMessage.MessageLength);
        }

        private void BuildMessageData()
        {
            queueMessage = new MQMessage();

            if(MessageId != null)
            {
                queueMessage.MessageId = MessageId;
            }

            if (CorrelationId != null)
            {
                queueMessage.CorrelationId = CorrelationId;
            }

            if (ReplyToQueueManager != null)
            {
                queueMessage.ReplyToQueueManagerName = ReplyToQueueManager;
            }

            if (ReplyToQueue != null)
            {
                queueMessage.ReplyToQueueName = ReplyToQueue;
            }

            if (ApplicationIdData != null)
            {
                queueMessage.ApplicationIdData = ApplicationIdData;
            }

            queueMessage.Format = MQC.MQFMT_STRING;
        }
    }
}
