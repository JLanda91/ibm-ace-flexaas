﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CZ.ESB.Unittest.TestTools.Exceptions
{
    public class FileFoundException : Exception
    {
        private string file;
        public FileFoundException(string file)
        {
            this.file = file;
        }

        public override string Message
        {
            get { return string.Format("File already exists at destination: {0}", file); }
        }
    }
}
