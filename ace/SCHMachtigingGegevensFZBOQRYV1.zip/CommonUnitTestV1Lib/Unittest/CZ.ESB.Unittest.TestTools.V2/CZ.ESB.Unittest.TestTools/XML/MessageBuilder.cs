﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace CZ.ESB.Unittest.TestTools.XML
{
    public class MessageBuilder
    {
        /// <summary>
        /// Call deze methode om bericht te bouwen van een file, met de gegeven namespace.
        /// </summary>
        /// <param name="fileName">File met het bericht er in</param>
        /// <param name="messageNamespace">Namespace voor het bericht</param>
        public static T BuildMessage<T>(string fileName, string messageNamespace)
        {
            T reqMsg;
            using (TextReader textReader = new StringReader(FILE.Files.ReadString(fileName)))
            {
                using (XmlTextReader reader = new XmlTextReader(textReader))
                {
                    XmlSerializer serializer = new XmlSerializer(typeof(T), messageNamespace);
                    reqMsg = (T)serializer.Deserialize(reader);
                }
            }
            return reqMsg;
        }
    }
}
