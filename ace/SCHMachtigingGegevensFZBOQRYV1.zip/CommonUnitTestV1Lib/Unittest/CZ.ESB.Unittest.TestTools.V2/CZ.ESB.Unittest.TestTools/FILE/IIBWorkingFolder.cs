﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CZ.ESB.Unittest.TestTools.Base;
using CZ.ESB.Unittest.TestTools.Exceptions;

namespace CZ.ESB.Unittest.TestTools.FILE
{
    public class IIBWorkingFolder
    {
        public  static string Folder { get; set; }

        public static void Initialize()
        {
            string file = @"C:\ProgramData\IBM\MQSI\common\profiles\mqsifilenodesrootdirectory.cmd";

            if (File.Exists(file))
            {
                string content = Files.ReadString(file);

                if (content.Contains("="))
                {
                    Folder = Path.Combine(content.Split('=')[1].Trim(), UnitTestHelper.GetNode());
                }
            }
            else
            {
                throw new IIBWorkingFolderNotFoundException();
            }
        }
    }
}

