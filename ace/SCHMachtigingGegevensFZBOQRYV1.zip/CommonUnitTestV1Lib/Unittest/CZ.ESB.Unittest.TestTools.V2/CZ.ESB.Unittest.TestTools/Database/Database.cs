﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CZ.ESB.Unittest.TestTools.FILE;

namespace CZ.ESB.Unittest.TestTools.Database
{
    public class Database
    {
        private SqlConnection connection;
        private string database;

        private Database()
        {
            
        }

        private static Database Connect(string db)
        {
            Database database = new Database();
            database.database = db;
            database.connection = new SqlConnection(ConfigurationManager.ConnectionStrings[database.database].ConnectionString);
            return database;
        }

        public static void ExecuteSqlFile(string db, string sqlFile)
        {
            Database database = Connect(db);
            string sqlFileContent = Files.ReadStringFromFileName(sqlFile);

            using (SqlCommand command = new SqlCommand(sqlFileContent, database.connection))
            {
                command.Connection.Open();
                command.ExecuteNonQuery();
            }
        }

        public static void Clean(string db, string table)
        {
            Database database = Connect(db);

            using (SqlCommand command = new SqlCommand(string.Format(CultureInfo.InvariantCulture, "TRUNCATE TABLE {0}", table), database.connection))
            {
                command.Connection.Open();
                command.ExecuteNonQuery();
            }
        }

        public static SqlDataReader Select(string db, string query)
        {
            Database database = Connect(db);

            using (SqlCommand command = new SqlCommand(query, database.connection))
            {

                command.Connection.Open();
                return command.ExecuteReader();
            }
        }
    }
}
