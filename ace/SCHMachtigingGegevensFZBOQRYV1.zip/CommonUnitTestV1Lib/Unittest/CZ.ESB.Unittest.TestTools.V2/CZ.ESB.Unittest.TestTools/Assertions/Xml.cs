﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;
using System.Xml.XPath;
using CZ.ESB.Unittest.TestTools.XML;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CZ.ESB.Unittest.TestTools.Assertions
{
    public class Xml
    {
        public void AreEqual(string xmlA, string xmlB)
        {
            XmlHelper.Compare(xmlA, xmlB);
        }

        public void AreEqualFileName(string xmlA, string fileName)
        {
            XmlHelper.CompareAgainstFile(xmlA, fileName);
        }

        public void AreEqual<T>(string xml, string xpath, T waarde)
        {
            var document = XDocument.Parse(xml);
            var waardeXml = document.XPathSelectElement(xpath).Value;

            Assert.IsTrue(((T) Convert.ChangeType(waardeXml, typeof(T))).Equals(waarde));
        }
    }
}
