﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Dispatcher;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace CZ.ESB.Unittest.TestTools.SOAP
{
    /// <summary>
    /// <see cref="IClientMessageInspector"/> waarmee de body van een SOAP bericht kan worden teruggegeven als string.
    /// </summary>
    internal class SOAPBodyClientMessageInspector : IClientMessageInspector
    {
        public event EventHandler<SoapBodyReceivedEventArgs> SoapBodyReceived;

        /// <summary>
        /// Wordt aangeroepen 
        /// </summary>
        /// <seealso cref="IClientMessageInspector.AfterReceiveReply(ref Message, object)"/>
        public void AfterReceiveReply(ref Message reply, object correlationState)
        {
            var eventArgs = new SoapBodyReceivedEventArgs();
            var replyXMLDocument = new XmlDocument();
            try
            {
                replyXMLDocument.LoadXml(reply.ToString());
            } catch (XmlException) {
                OnSoapBodyReceived(eventArgs);
                return;
            }
            var replyBody = replyXMLDocument.GetElementsByTagName("soapenv:Body");
            if (replyBody.Count > 0)
            {
                eventArgs.SoapBody = replyBody[0].InnerXml;
            }
            OnSoapBodyReceived(eventArgs);
        }

        /// <summary>
        /// Niet geimplementeerd.
        /// </summary>
        /// <seealso cref="IClientMessageInspector.BeforeSendRequest(ref Message, IClientChannel)"/>
        public object BeforeSendRequest(ref Message request, IClientChannel channel)
        {
            return null;
        }

        private void OnSoapBodyReceived(SoapBodyReceivedEventArgs e)
        {
            SoapBodyReceived?.Invoke(this, e);
        }
    }

    internal class SoapBodyReceivedEventArgs : EventArgs
    {
        public string SoapBody { get; set; }
    }

}
