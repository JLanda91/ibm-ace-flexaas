﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using CZ.ESB.Unittest.TestTools.MQ;
using System.ServiceModel;
using System.ServiceModel.Channels;
using IBM.WMQ;

namespace CZ.ESB.Unittest.TestTools.SOAP
{
    public class BackendSOAPStub : IDisposable
    {
        private Id messageId;

        private MQMessage content;

        private int pollingInterval = 100;
        private int pollingAttempts = 100;

        private int statusCode = 200;

        public BackendSOAPStub()
        {
            messageId = MessageIdGenerator.Generate();
        }

        public BackendSOAPStub ChangePollingInterval(int ms)
        {
            pollingInterval = ms;
            return this;
        }

        public BackendSOAPStub ChangePollingAttempts(int attempts)
        {
            pollingAttempts = attempts;
            return this;
        }

        public BackendSOAPStub ChangeStatusCode(int httpStatusCode)
        {
            statusCode = httpStatusCode;
            return this;
        }

        private string PrepareMessage(string msg)
        {
            msg = this.ParseHTTPOptions() + msg;
            return msg;
        }

        private string ParseHTTPOptions()
        {
            // Option1=Value1|Option2=Value2|...
            return "<CZSOAPHTTPStubOptions>" +
                "ReplyStatusCode=" + this.statusCode +
                "</CZSOAPHTTPStubOptions>";
        }

        public BackendSOAPStub AnswerWith(string msg)
        {
            
            MQConnect requestQueue = MQConnect.Connect(MQ.MQConstants.UnitTestQueueManager, MQConstants.MQQueue.SOAPRequestQueue);
            requestQueue.ChangePollingAttempts(pollingAttempts);
            requestQueue.ChangePollingInterval(pollingInterval);
            content = requestQueue.Get(true);

            MQConnect replyQueue = MQConnect.Connect(MQ.MQConstants.UnitTestQueueManager, MQConstants.MQQueue.SOAPReplyQueue);
            replyQueue.SetCorrelationId(content.MessageId);
            replyQueue.SendMessage(this.PrepareMessage(msg));

            return this;
        }

        public BackendSOAPStub AnswerWithBytes(byte[] data)
        {
            MQConnect requestQueue = MQConnect.Connect(MQ.MQConstants.UnitTestQueueManager, MQConstants.MQQueue.SOAPRequestQueue);
            requestQueue.ChangePollingAttempts(pollingAttempts);
            requestQueue.ChangePollingInterval(pollingInterval);
            content = requestQueue.Get(true);

            MQConnect replyQueue = MQConnect.Connect(MQ.MQConstants.UnitTestQueueManager, MQConstants.MQQueue.SOAPReplyQueue);
            replyQueue.SetCorrelationId(content.MessageId);
            replyQueue.SendMessage(data);

            return this;
        }

        public BackendSOAPStub AnswerWithDynamicString(Func<string, string> decision)
        {
            MQConnect requestQueue = MQConnect.Connect(MQ.MQConstants.UnitTestQueueManager, MQConstants.MQQueue.SOAPRequestQueue);
            requestQueue.ChangePollingAttempts(pollingAttempts);
            requestQueue.ChangePollingInterval(pollingInterval);
            content = requestQueue.Get(true);

            MQConnect replyQueue = MQConnect.Connect(MQ.MQConstants.UnitTestQueueManager, MQConstants.MQQueue.SOAPReplyQueue);
            replyQueue.SetCorrelationId(content.MessageId);
            replyQueue.SendMessage(this.PrepareMessage(decision(GetRequestMessage())));

            return this;
        }

        public string GetRequestMessage()
        {
            return content.ReadString(content.MessageLength);
        }

        public BackendSOAPStubRequest GetRequestHeader()
        {
            MQConnect requestHeaderQueue = MQConnect.Connect(MQ.MQConstants.UnitTestQueueManager, MQConstants.MQQueue.SOAPRequestHeaderQueue);
            requestHeaderQueue.ChangePollingAttempts(pollingAttempts);
            requestHeaderQueue.ChangePollingInterval(pollingInterval);
            var msg = requestHeaderQueue.Get(true);
            return BackendSOAPStubRequestParser.Parse(msg.ReadString(msg.MessageLength));
        }

        public static void Clean()
        {
            MQConnect.Clean(MQ.MQConstants.UnitTestQueueManager, MQConstants.MQQueue.SOAPRequestHeaderQueue);
            MQConnect.Clean(MQ.MQConstants.UnitTestQueueManager, MQConstants.MQQueue.SOAPRequestQueue);
            MQConnect.Clean(MQ.MQConstants.UnitTestQueueManager, MQConstants.MQQueue.SOAPReplyQueue);
        }

        public void Dispose()
        {

        }
    }
}