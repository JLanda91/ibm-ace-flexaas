﻿using System;
using System.ServiceModel;
using CZ.ESB.Unittest.TestTools.HelloWorldServiceReference;
using CZ.ESB.Unittest.TestTools.MQ;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CZ.ESB.Unittest.TestTools.SOAP
{
    public class SOAPUnitTestHelper
    {

        public static void TestAll()
        {
            NotAvailable();
        }

        public static void NotAvailable()
        {
            try
            {
                HelloWorldServiceReference.Hello_PortTypeClient client =
                    new Hello_PortTypeClient(new BasicHttpBinding(),
                        new EndpointAddress("http://localhost:7801/esb/unittest/notavailable/SayHello"));
                client.sayHello("Test");
            }
            catch (Exception ex)
            {
                Assert.AreEqual(ex.GetType().Name, typeof(EndpointNotFoundException).Name);
            }
        }
    }
}
