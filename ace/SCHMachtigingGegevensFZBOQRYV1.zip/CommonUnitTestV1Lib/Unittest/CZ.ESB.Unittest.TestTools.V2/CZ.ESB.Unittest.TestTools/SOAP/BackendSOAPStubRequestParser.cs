﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace CZ.ESB.Unittest.TestTools.SOAP
{
    public class BackendSOAPStubRequestParser
    {
        public static BackendSOAPStubRequest Parse(string request)
        {
            BackendSOAPStubRequest requestObject = new BackendSOAPStubRequest();

            StringBuilder msg = new StringBuilder();

            bool xmlStartTagHasBeenFound = false;

            string[] data = request.Split('\r');
            foreach (string datarow in data)
            {
                if (datarow.StartsWith("POST"))
                {
                    requestObject.PostUrl = datarow;
                }
                else if (datarow.Split(':').Length == 2 && !xmlStartTagHasBeenFound)
                {
                    if (requestObject.Headers == null)
                    {
                        requestObject.Headers = new Dictionary<string, string>();
                    }
                    string[] header = datarow.Split(':');
                    var list = header.ToList();
                    list.RemoveAt(0);
                    requestObject.Headers.Add(header[0], string.Join(":", list).Trim());
                }
                else if (!xmlStartTagHasBeenFound && datarow.StartsWith("\n<"))
                {
                    xmlStartTagHasBeenFound = true;
                    msg.AppendLine(datarow);
                }
                else if (xmlStartTagHasBeenFound)
                {
                    msg.AppendLine(datarow);
                }
            }

            requestObject.Message = XDocument.Parse(msg.ToString());

            return requestObject;
        }
    }
}
