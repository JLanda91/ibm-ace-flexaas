package nl.cz.esb.common.xpath.v1;

import java.util.List;

import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbNamespaceBindings;
import com.ibm.broker.plugin.MbXPath;
import com.ibm.broker.plugin.MbXPathVariables;

public class XPath 
{
	public static String evaluateXpath(com.ibm.broker.plugin.MbElement root, String xpath, String namespaces) {
		return evaluateXpathVars(root, xpath, namespaces);
	}
	public static String evaluateXpath(com.ibm.broker.plugin.MbElement root, String xpath, String namespaces, String var1) {
		return evaluateXpathVars(root, xpath, namespaces, var1);
	}
	public static String evaluateXpath(com.ibm.broker.plugin.MbElement root, String xpath, String namespaces, String var1, String var2) {
		return evaluateXpathVars(root, xpath, namespaces, var1, var2);
	}
	public static String evaluateXpath(com.ibm.broker.plugin.MbElement root, String xpath, String namespaces, String var1, String var2, String var3) {
		return evaluateXpathVars(root, xpath, namespaces, var1, var2, var3);
	}
	
	public static Boolean evaluateXpathNode(com.ibm.broker.plugin.MbElement[] root, String xpath, String namespaces) {
		return evaluateXpathNodeVars(root, xpath, namespaces);
	}
	public static Boolean evaluateXpathNode(com.ibm.broker.plugin.MbElement[] root, String xpath, String namespaces, String var1) {
		return evaluateXpathNodeVars(root, xpath, namespaces, var1);
	}
	public static Boolean evaluateXpathNode(com.ibm.broker.plugin.MbElement[] root, String xpath, String namespaces, String var1, String var2) {
		return evaluateXpathNodeVars(root, xpath, namespaces, var1, var2);
	}
	public static Boolean evaluateXpathNode(com.ibm.broker.plugin.MbElement[] root, String xpath, String namespaces, String var1, String var2, String var3) {
		return evaluateXpathNodeVars(root, xpath, namespaces, var1, var2, var3);
	}
	
	@SuppressWarnings("unchecked")
	private static String evaluateXpathVars(com.ibm.broker.plugin.MbElement root, String xpath, String namespaces, String...vars ) {
		try {

			// Get string value from first (and only) MbElement in list returned from evaluate
			Object obj = evaluate(root, xpath, namespaces, vars);
			if(obj instanceof Boolean)
			{
				return Boolean.toString((Boolean)obj);
			}
			else if(obj instanceof Double)
			{
				return Double.toString((Double)obj);
			}
			else if(obj instanceof String)
			{
				return (String)obj;
			}
			else if(obj instanceof List)
			{
				return ((List<MbElement>)obj).get(0).getValueAsString();
			}			
			return null;
			
		} catch (MbException e) {
			// MbException, mandatory and throws is not allowed (see InfoCenter)
			return null;
		} catch (IndexOutOfBoundsException e) {
			// thrown when evaluateXpath find no matching MbElements
			return null;
		}
	}	
	
	@SuppressWarnings("unchecked")
	private static Boolean evaluateXpathNodeVars(com.ibm.broker.plugin.MbElement[] root, String xpath, String namespaces, String...vars  ) {
		try {
			
			Object obj = evaluate(root[0], xpath, namespaces, vars);;
			if(obj instanceof List)
			{
				root[0] = ((List<MbElement>)obj).get(0);
				return true;
			}			
			return false;
			
		} catch (IndexOutOfBoundsException e) {
			// thrown when evaluateXpath find no matching MbElements
			return false;
		}
	}
	
	private static Object evaluate (com.ibm.broker.plugin.MbElement root, String xpath, String namespaces, String...vars ) {
		try {
			// Create XPath expression with paymentstream as root element.
	
			// split namespaces  
			MbNamespaceBindings xpns = new MbNamespaceBindings();
			String[] prefixWithNS = namespaces.split(",");  
			for(int i =0; i < prefixWithNS.length ; i++) {
				//are namespaces available
				if (prefixWithNS[i].trim().equals("") == false) {

					// add namespace prefixes
					String[] splitPrefixNS = prefixWithNS[i].split("=",2);
					splitPrefixNS[1] = splitPrefixNS[1].replaceAll("^[\"'](.*)[\"']$", "$1");
					if (splitPrefixNS[0].equals("xmlns")) {
						xpns.setDefaultNamespace(splitPrefixNS[1]);
	
					} else {
						xpns.addBinding(splitPrefixNS[0].substring(6), splitPrefixNS[1]);					
					}
				}
			}

			// Assign vars to variables $a, $b, etc.
			MbXPathVariables xpv = new MbXPathVariables(); 
			for (Integer i = 0; i < vars.length; i++) {
				xpv.assign(String.valueOf((char)((int)('a')+i)), vars[i]);
			}
			
			return root.evaluateXPath(xpath, xpns, xpv);
			
		} catch (MbException e) {
			// MbException, mandatory and throws is not allowed (see InfoCenter)
			return false;
		}
	}
}

