﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Threading.Tasks;
using CZ.ESB.Unittest.TestTools;
using CZ.ESB.Unittest.TestTools.Base;
using CZ.ESB.Unittest.TestTools.Database;
using CZ.ESB.Unittest.TestTools.FILE;
using CZ.ESB.Unittest.TestTools.HTTP;
using CZ.ESB.Unittest.TestTools.MQ;
using CZ.ESB.Unittest.TestTools.SOAP;
using CZ.ESB.Unittest.TestTools.XML;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using CZ.ESB.Unittest.TestTools.SecureStore;
using System.ServiceModel;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using Integration.UnitTest.SCHOphalenMaximaleVergoedingGegevensFZBOQRYV1;
using System.Diagnostics;
using System.Linq;

namespace Integration.Test
{
    [TestClass]
    public class UnitTest
    {
        

        [TestMethod]
        public void Test_Standard_Procedures()
        {
			SOAPUnitTestHelper.TestAll();
			MQUnitTestHelper.TestAll();
        }


    [TestMethod]
    public void getMaximaleVergoedingGegevens_OKResponse()
    {
        using (BackendHTTPStub stub = new BackendHTTPStub())
        {
            sch_ophalenmaximalevergoedinggegevensqryv1Port12TypeClient client = new sch_ophalenmaximalevergoedinggegevensqryv1Port12TypeClient();

            string url = UnitTestHelper.ReadConfigurationSetting("Url");

            client.Endpoint.Address = new EndpointAddress(url);

            getMaximaleVergoedingGegevens reqMsg = BuildMessage("getMaximaleVergoedingGegevens_OK_Request.xml");
            Parallel.Invoke(() =>
            {
                /*  var answer = client.getMaximaleVergoedingGegevens(reqMsg);  */
                string fileName = @"c:\temp\test123.txt";
                FileStream stream = new FileStream(fileName, FileMode.Create);
                using (StreamWriter writer = new StreamWriter(stream))
                {
                    var answer = client.getMaximaleVergoedingGegevens(reqMsg);
                    var rspnse = responseAsString(answer);
                    /*  writer.Write(rspnse);  */
                    writer.Write(responseAsString(answer));
                    XmlHelper.CompareAgainstFile(rspnse, "getMaximaleVergoedingGegevens_OK_Response.xml");
                }
                /*  XmlHelper.CompareAgainstFile(responseAsString(answer), "getMaximaleVergoedingGegevens_OK_Response.xml");  */
                }, () =>
                {
                    stub.AnswerWith(Files.ReadString("getMaximaleVergoedingGegevens_OK_TopicusResponse.txt"));
                });


                var requestmessage = stub.GetRequestMessage();

                Assert.AreEqual(Files.ReadString("getMaximaleVergoedingGegevens_OK_TopicusRequest.txt"), requestmessage.Message);

            }
        }


        [TestMethod]
        public void getMaximaleVergoedingGegevens_NotaOKResponse()
        {
            using (BackendHTTPStub stub = new BackendHTTPStub())
            {
                sch_ophalenmaximalevergoedinggegevensqryv1Port12TypeClient client = new sch_ophalenmaximalevergoedinggegevensqryv1Port12TypeClient();

                string url = UnitTestHelper.ReadConfigurationSetting("Url");

                client.Endpoint.Address = new EndpointAddress(url);

                getMaximaleVergoedingGegevens reqMsg = BuildMessage("getMaximaleVergoedingGegevens_NotaOK_Request.xml");
                Parallel.Invoke(() =>
                {
                    /*  var answer = client.getMaximaleVergoedingGegevens(reqMsg);  */
                    string fileName = @"c:\temp\test123.txt";
                    FileStream stream = new FileStream(fileName, FileMode.Create);
                    using (StreamWriter writer = new StreamWriter(stream))
                    {
                        var answer = client.getMaximaleVergoedingGegevens(reqMsg);
                        var rspnse = responseAsString(answer);
                        writer.Write(responseAsString(answer));
                        /*  writer.Write(rspnse);  */
                        XmlHelper.CompareAgainstFile(rspnse, "getMaximaleVergoedingGegevens_NotaOK_Response.xml");
                    }
                    /*  XmlHelper.CompareAgainstFile(responseAsString(answer), "getMaximaleVergoedingGegevens_NotaOK_Response.xml");  */
                }, () =>
                {
                    stub.AnswerWith(Files.ReadString("getMaximaleVergoedingGegevens_NotaOK_TopicusResponse.txt"));
                });


                var requestmessage = stub.GetRequestMessage();

                Assert.AreEqual(Files.ReadString("getMaximaleVergoedingGegevens_NotaOK_TopicusRequest.txt"), requestmessage.Message);

            }
        }


        [TestMethod]
        public void getMaximaleVergoedingGegevens_PrestatiesOKResponse()
        {
            using (BackendHTTPStub stub = new BackendHTTPStub())
            {
                sch_ophalenmaximalevergoedinggegevensqryv1Port12TypeClient client = new sch_ophalenmaximalevergoedinggegevensqryv1Port12TypeClient();

                string url = UnitTestHelper.ReadConfigurationSetting("Url");

                client.Endpoint.Address = new EndpointAddress(url);

                getMaximaleVergoedingGegevens reqMsg = BuildMessage("getMaximaleVergoedingGegevens_PrestatiesOK_Request.xml");
                Parallel.Invoke(() =>
                {
                    /* var answer = client.getMaximaleVergoedingGegevens(reqMsg); */
                    string fileName = @"c:\temp\test123.txt";
                    FileStream stream = new FileStream(fileName, FileMode.Create);
                    using (StreamWriter writer = new StreamWriter(stream))
                    {
                        var answer = client.getMaximaleVergoedingGegevens(reqMsg);
                        var rspnse = responseAsString(answer);
                        writer.Write(responseAsString(answer));
                        /* writer.Write(rspnse);  */
                        XmlHelper.CompareAgainstFile(rspnse, "getMaximaleVergoedingGegevens_PrestatiesOK_Response.xml");
                    };
                    /*  XmlHelper.CompareAgainstFile(responseAsString(answer), "getMaximaleVergoedingGegevens_PrestatiesOK_Response.xml");  */
                }, () =>
                {
                    stub.AnswerWith(Files.ReadString("getMaximaleVergoedingGegevens_PrestatiesOK_TopicusResponse.txt"));
                });

                var requestmessage = stub.GetRequestMessage();

                Assert.AreEqual(Files.ReadString("getMaximaleVergoedingGegevens_PrestatiesOK_TopicusRequest.txt"), requestmessage.Message);

            }
        }


        [TestMethod]
        public void getMaximaleVergoedingGegevens_PrestGrpOKResponse()
        {
            using (BackendHTTPStub stub = new BackendHTTPStub())
            {
                sch_ophalenmaximalevergoedinggegevensqryv1Port12TypeClient client = new sch_ophalenmaximalevergoedinggegevensqryv1Port12TypeClient();

                string url = UnitTestHelper.ReadConfigurationSetting("Url");

                client.Endpoint.Address = new EndpointAddress(url);

                getMaximaleVergoedingGegevens reqMsg = BuildMessage("getMaximaleVergoedingGegevens_PrestGrpOK_Request.xml");
                Parallel.Invoke(() =>
                
                {
                    /* var answer = client.getMaximaleVergoedingGegevens(reqMsg); */
                    string fileName = @"c:\temp\test123.txt";
                    FileStream stream = new FileStream(fileName, FileMode.Create);
                    using (StreamWriter writer = new StreamWriter(stream))
                    {
                        var answer = client.getMaximaleVergoedingGegevens(reqMsg);
                        var rspnse = responseAsString(answer);
                        /*  writer.Write(responseAsString(answer)); */
                        writer.Write(rspnse);
                        XmlHelper.CompareAgainstFile(rspnse, "getMaximaleVergoedingGegevens_PrestGrpOK_Response.xml"); 
                    }
                    /* XmlHelper.CompareAgainstFile(responseAsString(answer), "getMaximaleVergoedingGegevens_PrestGrpOK_Response.xml"); */
                }, () =>
                {
                    stub.AnswerWith(Files.ReadString("getMaximaleVergoedingGegevens_PrestGrpOK_TopicusResponse.txt"));
                });

                var requestmessage = stub.GetRequestMessage();

                Assert.AreEqual(Files.ReadString("getMaximaleVergoedingGegevens_PrestGrpOK_TopicusRequest.txt"), requestmessage.Message);

            }
        }


        [TestMethod]
        public void getMaximaleVergoedingGegevens_NotaFalseResponse()
        {
            using (BackendHTTPStub stub = new BackendHTTPStub())
            {
                sch_ophalenmaximalevergoedinggegevensqryv1Port12TypeClient client = new sch_ophalenmaximalevergoedinggegevensqryv1Port12TypeClient();

                string url = UnitTestHelper.ReadConfigurationSetting("Url");

                client.Endpoint.Address = new EndpointAddress(url);

                getMaximaleVergoedingGegevens reqMsg = BuildMessage("getMaximaleVergoedingGegevens_NotaFalse_Request.xml");
                Parallel.Invoke(() =>
                {
                    /*  var answer = client.getMaximaleVergoedingGegevens(reqMsg);  */
                    string fileName = @"c:\temp\test123.txt";
                    FileStream stream = new FileStream(fileName, FileMode.Create);
                       using (StreamWriter writer = new StreamWriter(stream))
                    {
                        var answer = client.getMaximaleVergoedingGegevens(reqMsg);
                        var rspnse = responseAsString(answer);
                        writer.Write(responseAsString(answer));
                        /*  writer.Write(rspnse);  */
                        XmlHelper.CompareAgainstFile(rspnse, "getMaximaleVergoedingGegevens_NotaFalse_Response.xml");
                    }
                    /*  XmlHelper.CompareAgainstFile(responseAsString(answer), "getMaximaleVergoedingGegevens_NotaFalse_Response.xml");  */
                }, () =>
                {
                    stub.AnswerWith(Files.ReadString("getMaximaleVergoedingGegevens_NotaFalse_TopicusResponse.txt"));
                });


                var requestmessage = stub.GetRequestMessage();

                Assert.AreEqual(Files.ReadString("getMaximaleVergoedingGegevens_NotaFalse_TopicusRequest.txt"), requestmessage.Message);

            }
        }


        [TestMethod]
        public void getMaximaleVergoedingGegevens_TopXFalseResponse()
        {
            using (BackendHTTPStub stub = new BackendHTTPStub())
            {
                sch_ophalenmaximalevergoedinggegevensqryv1Port12TypeClient client = new sch_ophalenmaximalevergoedinggegevensqryv1Port12TypeClient();

                string url = UnitTestHelper.ReadConfigurationSetting("Url");

                client.Endpoint.Address = new EndpointAddress(url);

                getMaximaleVergoedingGegevens reqMsg = BuildMessage("getMaximaleVergoedingGegevens_TopXFalse_Request.xml");
                Parallel.Invoke(() =>
                {
                    /*  var answer = client.getMaximaleVergoedingGegevens(reqMsg);  */
                    string fileName = @"c:\temp\test123.txt";
                    FileStream stream = new FileStream(fileName, FileMode.Create);
                    using (StreamWriter writer = new StreamWriter(stream))
                    {
                        var answer = client.getMaximaleVergoedingGegevens(reqMsg);
                        var rspnse = responseAsString(answer);
                        writer.Write(responseAsString(answer));
                        /*  writer.Write(rspnse);  */
                        XmlHelper.CompareAgainstFile(rspnse, "getMaximaleVergoedingGegevens_TopXFalse_Response.xml");
                    }
                    /*  XmlHelper.CompareAgainstFile(responseAsString(answer), "getMaximaleVergoedingGegevens_NotaFalse_Response.xml");  */
                }, () =>
                {
                    stub.AnswerWith(Files.ReadString("getMaximaleVergoedingGegevens_TopXFalse_TopicusResponse.txt"));
                });


                var requestmessage = stub.GetRequestMessage();

                Assert.AreEqual(Files.ReadString("getMaximaleVergoedingGegevens_TopXFalse_TopicusRequest.txt"), requestmessage.Message);

            }
        }


        [TestMethod]
        public void getMaximaleVergoedingGegevens_TopXand5FalseResponse()
        {
            using (BackendHTTPStub stub = new BackendHTTPStub())
            {
                sch_ophalenmaximalevergoedinggegevensqryv1Port12TypeClient client = new sch_ophalenmaximalevergoedinggegevensqryv1Port12TypeClient();

                string url = UnitTestHelper.ReadConfigurationSetting("Url");

                client.Endpoint.Address = new EndpointAddress(url);

                getMaximaleVergoedingGegevens reqMsg = BuildMessage("getMaximaleVergoedingGegevens_TopXand5False_Request.xml");
                Parallel.Invoke(() =>
                {
                    /*  var answer = client.getMaximaleVergoedingGegevens(reqMsg);  */
                    string fileName = @"c:\temp\test123.txt";
                    FileStream stream = new FileStream(fileName, FileMode.Create);
                    using (StreamWriter writer = new StreamWriter(stream))
                    {
                        var answer = client.getMaximaleVergoedingGegevens(reqMsg);
                        var rspnse = responseAsString(answer);
                        writer.Write(responseAsString(answer));
                        /*  writer.Write(rspnse);  */
                        XmlHelper.CompareAgainstFile(rspnse, "getMaximaleVergoedingGegevens_TopXand5False_Response.xml");
                    }
                    /*  XmlHelper.CompareAgainstFile(responseAsString(answer), "getMaximaleVergoedingGegevens_NotaFalse_Response.xml");  */
                }, () =>
                {
                    stub.AnswerWith(Files.ReadString("getMaximaleVergoedingGegevens_TopXand5False_TopicusResponse.txt"));
                });


                var requestmessage = stub.GetRequestMessage();

                Assert.AreEqual(Files.ReadString("getMaximaleVergoedingGegevens_TopXand5False_TopicusRequest.txt"), requestmessage.Message);

            }
        }


        [TestMethod]
        public void getMaximaleVergoedingGegevens_Top5FalseResponse()
        {
            using (BackendHTTPStub stub = new BackendHTTPStub())
            {
                sch_ophalenmaximalevergoedinggegevensqryv1Port12TypeClient client = new sch_ophalenmaximalevergoedinggegevensqryv1Port12TypeClient();

                string url = UnitTestHelper.ReadConfigurationSetting("Url");

                client.Endpoint.Address = new EndpointAddress(url);

                getMaximaleVergoedingGegevens reqMsg = BuildMessage("getMaximaleVergoedingGegevens_Top5False_Request.xml");
                Parallel.Invoke(() =>
                {
                    /*  var answer = client.getMaximaleVergoedingGegevens(reqMsg);  */
                    string fileName = @"c:\temp\test123.txt";
                    FileStream stream = new FileStream(fileName, FileMode.Create);
                    using (StreamWriter writer = new StreamWriter(stream))
                    {
                        var answer = client.getMaximaleVergoedingGegevens(reqMsg);
                        var rspnse = responseAsString(answer);
                        writer.Write(responseAsString(answer));
                        /*  writer.Write(rspnse);  */
                        XmlHelper.CompareAgainstFile(rspnse, "getMaximaleVergoedingGegevens_Top5False_Response.xml");
                    }
                    /*  XmlHelper.CompareAgainstFile(responseAsString(answer), "getMaximaleVergoedingGegevens_NotaFalse_Response.xml");  */
                }, () =>
                {
                    stub.AnswerWith(Files.ReadString("getMaximaleVergoedingGegevens_Top5False_TopicusResponse.txt"));
                });


                var requestmessage = stub.GetRequestMessage();

                Assert.AreEqual(Files.ReadString("getMaximaleVergoedingGegevens_Top5False_TopicusRequest.txt"), requestmessage.Message);

            }
        }


        [TestMethod]
        public void getMaximaleVergoedingGegevens_404_Response()
        {
            using (BackendHTTPStub stub = new BackendHTTPStub())
            {
                sch_ophalenmaximalevergoedinggegevensqryv1Port12TypeClient client = new sch_ophalenmaximalevergoedinggegevensqryv1Port12TypeClient();

                string url = UnitTestHelper.ReadConfigurationSetting("Url");

                client.Endpoint.Address = new EndpointAddress(url);

                getMaximaleVergoedingGegevens reqMsg = BuildMessage("getMaximaleVergoedingGegevens_OK_Request.xml");
                Parallel.Invoke(() =>
                {
                    var answer = client.getMaximaleVergoedingGegevens(reqMsg);
                    XmlHelper.CompareAgainstFile(responseAsString(answer), "getMaximaleVergoedingGegevens_404_Response.xml");
                }, () =>
                {
                    stub.ChangeStatusCode(404);
                    stub.AnswerWith(Files.ReadString("getMaximaleVergoedingGegevens_404_TopicusResponse.txt"));
                });


                var requestmessage = stub.GetRequestMessage();

                Assert.AreEqual(Files.ReadString("getMaximaleVergoedingGegevens_OK_TopicusRequest.txt"), requestmessage.Message);

            }
        }


        [TestMethod]
        public void getMaximaleVergoedingGegevens_400_Response()
        {
            using (BackendHTTPStub stub = new BackendHTTPStub())
            {
                sch_ophalenmaximalevergoedinggegevensqryv1Port12TypeClient client = new sch_ophalenmaximalevergoedinggegevensqryv1Port12TypeClient();

                string url = UnitTestHelper.ReadConfigurationSetting("Url");

                client.Endpoint.Address = new EndpointAddress(url);

                getMaximaleVergoedingGegevens reqMsg = BuildMessage("getMaximaleVergoedingGegevens_400_BadRequest.xml");

                System.DateTime startTime = System.DateTime.Now;

                System.Threading.Thread.Sleep(1000);

                Parallel.Invoke(() =>
                {
                    try
                    {
                        var answer = client.getMaximaleVergoedingGegevens(reqMsg);
                    }
                    catch
                    {
                        //Do nothing
                    }
                    
                    //XmlHelper.CompareAgainstFile(responseAsString(answer), "getMaximaleVergoedingGegevens_404_Response.xml");
                }, () =>
                {
                    stub.ChangeStatusCode(400);
                    stub.AnswerWith(Files.ReadString("getMaximaleVergoedingGegevens_400_TopicusResponse.txt"));
                });


                var requestmessage = stub.GetRequestMessage();

                Assert.AreEqual(Files.ReadString("getMaximaleVergoedingGegevens_400_TopicusBadRequest.txt"), requestmessage.Message);

                
                System.Threading.Thread.Sleep(2000);
                //Get only the application event logs durign execution of this test
                EventLog appLog = new EventLog("Application");
                var entries = appLog.Entries.Cast<EventLogEntry>()
                             .Where(x => x.TimeGenerated >= startTime)
                             .Where(x => x.Source.Contains("IBM Integration"))
                             .Where(x => x.Message.Contains("nl.cz.esb.sch.maxvergoedingggvnsfzbo.qry.v1.SCHMaxVergoedingGgvnsFZBOQRYV1.getMaximaleVergoedingGegevens.RestErrorHandler.HandleRestError"))
                             .ToList();

                //Verify that the expected message is present
                string targetMessage = "Geen beperkend zoekpad opgegeven";
                bool messageFound = false;
                foreach (EventLogEntry entry in entries)
                {
                    messageFound |= entry.Message.Contains(targetMessage);
                }
                Assert.IsTrue(messageFound);

            }
        }


        [TestMethod]
        public void getMaximaleVergoedingGegevens_Failure_Response()
        {
            using (BackendHTTPStub stub = new BackendHTTPStub())
            {
                sch_ophalenmaximalevergoedinggegevensqryv1Port12TypeClient client = new sch_ophalenmaximalevergoedinggegevensqryv1Port12TypeClient();

                string url = UnitTestHelper.ReadConfigurationSetting("Url");

                client.Endpoint.Address = new EndpointAddress(url);

                getMaximaleVergoedingGegevens reqMsg = BuildMessage("getMaximaleVergoedingGegevens_OK_Request.xml");

                System.DateTime startTime = System.DateTime.Now;

                System.Threading.Thread.Sleep(1000);

                Parallel.Invoke(() =>
                {
                    try
                    {
                        var answer = client.getMaximaleVergoedingGegevens(reqMsg);
                    }
                    catch {
                        //Do nothing
                    }                    
                }, () =>
                {
                    // We send a dummy xml string so that json parsing error happens
                    stub.AnswerWith(Files.ReadString("getMaximaleVergoedingGegevens_Failure_TopicusResponse.txt"));
                });


                var requestmessage = stub.GetRequestMessage();

                Assert.AreEqual(Files.ReadString("getMaximaleVergoedingGegevens_OK_TopicusRequest.txt"), requestmessage.Message);

                System.Threading.Thread.Sleep(2000);
                //Get only the application event logs durign execution of this test
                EventLog appLog = new EventLog("Application");
                var entries = appLog.Entries.Cast<EventLogEntry>()
                             .Where(x => x.TimeGenerated >= startTime)
                             .Where(x => x.Source.Contains("IBM Integration"))
                             .Where(x => x.Message.Contains("not a valid JSON message"))
                             .ToList();

                //Verify that the expected message is present
                string targetMessage = "A JSON parsing error occurred";
                bool messageFound = false;
                foreach (EventLogEntry entry in entries)
                {
                    messageFound |= entry.Message.Contains(targetMessage);
                }
                Assert.IsTrue(messageFound);
            }
        }

        [TestMethod]
        public void getMaximaleVergoedingGegevens_500StatusCodeOnly_Response()
        {
            using (BackendHTTPStub stub = new BackendHTTPStub())
            {
                sch_ophalenmaximalevergoedinggegevensqryv1Port12TypeClient client = new sch_ophalenmaximalevergoedinggegevensqryv1Port12TypeClient();

                string url = UnitTestHelper.ReadConfigurationSetting("Url");

                client.Endpoint.Address = new EndpointAddress(url);

                getMaximaleVergoedingGegevens reqMsg = BuildMessage("getMaximaleVergoedingGegevens_Invalid_Request.xml");

                System.DateTime startTime = System.DateTime.Now;

                System.Threading.Thread.Sleep(1000);

                Parallel.Invoke(() =>
                {
                    try
                    {
                        var answer = client.getMaximaleVergoedingGegevens(reqMsg);
                    }
                    catch
                    {
                        //Do nothing
                    }
                                      
                }, () =>
                {
                    //In case of invalid zorgverzekerdeidentifier with extra digits,backend has internal error and sends only 500 status code 
                    stub.ChangeStatusCode(500);
                    stub.AnswerWithStatuscode(500);
                });


                var requestmessage = stub.GetRequestMessage();

                Assert.AreEqual(Files.ReadString("getMaximaleVergoedingGegevens_Invalid_TopicusRequest.txt"), requestmessage.Message);

                System.Threading.Thread.Sleep(2000);
                //Get only the application event logs durign execution of this test
                EventLog appLog = new EventLog("Application");
                var entries = appLog.Entries.Cast<EventLogEntry>()
                             .Where(x => x.TimeGenerated >= startTime)
                             .Where(x => x.Source.Contains("IBM Integration"))
                             .Where(x => x.Message.Contains("nl.cz.esb.sch.maxvergoedingggvnsfzbo.qry.v1.SCHMaxVergoedingGgvnsFZBOQRYV1.getMaximaleVergoedingGegevens.RestErrorHandler.HandleRestError"))
                             .ToList();

                //Verify that the expected message is present
                string targetMessage = "Error response = ";
                bool messageFound = false;
                foreach (EventLogEntry entry in entries)
                {
                    messageFound |= entry.Message.Contains(targetMessage);
                }
                Assert.IsTrue(messageFound);

            }
        }

        public getMaximaleVergoedingGegevens BuildMessage(string fileName)
        {
            getMaximaleVergoedingGegevens reqMsg;

            using (TextReader textReader = new StringReader(Files.ReadString(fileName)))
            {
                using (XmlTextReader reader = new XmlTextReader(textReader))
                {
                    XmlSerializer serializer = new XmlSerializer(typeof(getMaximaleVergoedingGegevens), "urn:cz:srv:model:sch:ophlnmaxvergoedingggvns:qry:v1");
                    reqMsg = (getMaximaleVergoedingGegevens)serializer.Deserialize(reader);
                }
            }
            return reqMsg;

        }

        public string responseAsString(getMaximaleVergoedingGegevensResponse response)
        {
            string responseStr;
            using (var stringwriter = new System.IO.StringWriter())
            {
                XmlSerializer serializer = new XmlSerializer(typeof(getMaximaleVergoedingGegevensResponse), "urn:cz:srv:model:sch:ophlnmaxvergoedingggvns:qry:v1");
                serializer.Serialize(stringwriter, response);
                responseStr = stringwriter.ToString();
            }
            return responseStr;
        }

        [TestCleanup]
        [TestInitialize]
        public void Cleanup()
        {
                     
            BackendHTTPStub.Clean();
        }

        [ClassInitialize]
        public static void InitizalizeClass(TestContext context)
        {
            
        }

        [ClassCleanup]
        public static void CleanupClass()
        {
            
        }
                        	
    }
}
