package nl.cz.esb.common.mapping.v1;

public class VertaalTabelMappingTransform {

	/**
	 * Sample method that can be called from a Mapping Custom Java transform.
	 * The content of this method provides the implementation for the Custom Java transform.
	 */
	public static java.lang.String VertaalKeyTransform(
			java.lang.String ConfigKeyName,java.lang.String VertaalKey,java.lang.String OutFieldName) {
		
		return CacheJSONVertaalTabel.getValueFromVertaalTabel(ConfigKeyName, VertaalKey,OutFieldName);
	}

}