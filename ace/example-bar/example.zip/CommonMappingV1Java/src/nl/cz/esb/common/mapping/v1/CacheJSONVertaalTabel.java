package nl.cz.esb.common.mapping.v1;

import java.util.HashMap;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;

import com.ibm.broker.config.proxy.BrokerProxy;
import com.ibm.broker.config.proxy.ConfigManagerProxyLoggedException;
import com.ibm.broker.config.proxy.ConfigManagerProxyPropertyNotInitializedException;
import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;

public class CacheJSONVertaalTabel extends MbJavaComputeNode {
	
	public static Map<String, Map<String, JSONObject>> ConfigMaps;
	private static BrokerProxy bp;

	@Override
	public void onInitialize() throws MbException {
		
		// Get application name
		String appName = getMessageFlow().getApplicationName();
		appName = appName.replace("App", "");
		String csName = appName.concat("Generic");
		
		
		ConfigMaps = new HashMap<String, Map<String, JSONObject>>();
		//If there are more keys then separate it by comma
		String ConfigKeyValues = (String)getUserDefinedAttribute("ConfigServiceKey");
		String[] ConfigKeyValueArray = ConfigKeyValues.split(",");
				
		try {
			//Connect brokerproxy only once!!!
			if(bp==null)
			{
				bp=BrokerProxy.getLocalInstance();
			}	
			
			//Iterate over config keys. Use the following format
			// For only one vertaal table --> currentStatusCode:currentExterneStatusName
			// For more vertaal tables --> currentStatusCode:currentExterneStatusName,currentStatusCode:indicatieInbehandeling
			for (int i = 0; i < ConfigKeyValueArray.length; i++) {
				Map<String , JSONObject> ConfigMap = new HashMap<String,JSONObject>();
				
				
				String ConfigKey = ConfigKeyValueArray[i];
				
				
				String udcs = "UserDefined/".concat(csName).concat("/").concat(ConfigKey);
				String udcsValue = bp.getConfigurableServiceProperty(udcs);

				JSONArray vtarray = new JSONArray(udcsValue);
				for (int j = 0; j < vtarray.length(); j++) 
				{
					JSONObject subObject = vtarray.getJSONObject(j);
		            String vtkey = subObject.getString("keyname");
		            JSONObject vtvalueObj = subObject.getJSONObject("keyvalue");
		            
		            ConfigMap.put(vtkey, vtvalueObj);
				}
				
				ConfigMaps.put(ConfigKey, ConfigMap);
			}
			
			
			bp.disconnect();
		} catch (ConfigManagerProxyPropertyNotInitializedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ConfigManagerProxyLoggedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");
		MbOutputTerminal alt = getOutputTerminal("alternate");

		MbMessage inMessage = inAssembly.getMessage();
		MbMessageAssembly outAssembly = null;
		try {
			// create new message as a copy of the input
			MbMessage outMessage = new MbMessage(inMessage);
			outAssembly = new MbMessageAssembly(inAssembly, outMessage);
			// ----------------------------------------------------------
			// Add user code below
			
			// End of user code
			// ----------------------------------------------------------
		} catch (MbException e) {
			// Re-throw to allow Broker handling of MbException
			throw e;
		} catch (RuntimeException e) {
			// Re-throw to allow Broker handling of RuntimeException
			throw e;
		} catch (Exception e) {
			// Consider replacing Exception with type(s) thrown by user code
			// Example handling ensures all exceptions are re-thrown to be handled in the flow
			throw new MbUserException(this, "evaluate()", "", "", e.toString(),
					null);
		}
		// The following should only be changed
		// if not propagating message to the 'out' terminal
		out.propagate(outAssembly);

	}
	
	public static String getValueFromVertaalTabel(String ConfigKeyName,String VertaalKey,String OutFieldName){
		
		Map<String, JSONObject> VertaalTabel = ConfigMaps.get(ConfigKeyName);
		JSONObject VertaalObj = VertaalTabel.get(VertaalKey);
		String VertaaldeWaarde = VertaalObj.getString(OutFieldName);
		if(VertaaldeWaarde != null && VertaaldeWaarde.length() > 0){
			return VertaaldeWaarde;
		}else{
			return "Onbekend";
		}
		
	}

}
