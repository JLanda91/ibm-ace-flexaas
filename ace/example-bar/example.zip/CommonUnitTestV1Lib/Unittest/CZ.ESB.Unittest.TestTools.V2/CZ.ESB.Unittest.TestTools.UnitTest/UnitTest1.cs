﻿using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using CZ.ESB.Unittest.TestTools.FILE;
using CZ.ESB.Unittest.TestTools.MQ;
using CZ.ESB.Unittest.TestTools.XML;
using CZ.ESB.Unittest.TestTools.SecureStore;
using IBM.WMQ;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CZ.ESB.Unittest.TestTools.UnitTest
{
    [TestClass]
    public class UnitTest1
    {
        
        [TestMethod]
        public void SecureConfigTest()
        {
            SecureStoreWriter.StoreEncryptedValue("Service", "Key", "Value");
        }

        [TestMethod]
        public void TestMethod1()
        {
            MQNewTopic.Connect("JORN.TEST", "JORN/TEST", true);
            /*
            MQAliasQueue.Connect("VER.TAAK.COM.ASTV1.RQST.AQ", "VER.TAAK.COM.SYSV1.RQST.LQ");

            MQAliasQueue.ProcessAll();

            MQAliasQueue.RestoreAll();*/
        }

        [TestMethod]
        public void TestMethod2()
        {
            /*
            MQNewQueue.Connect("TEST.BQ.UNITTEST", 1234455);
            MQNewQueue.Connect("TEST.LQ.UNITTEST", "TEST.BQ.UNITTEST", true);
            MQNewQueue.Connect("TEST.AQ.UNITTEST", "TEST.LQ.UNITTEST");
            MQNewQueue.Connect("TEST.AQ.UNITTEST2", MQNewQueue.QueueType.ALIAS);
            MQNewQueue.ProcessAll();
            System.Threading.Thread.Sleep(1000);
            
            MQDeleteQueue.Connect("TEST.LQ.UNITTEST");
            MQDeleteQueue.ProcessAll();
            System.Threading.Thread.Sleep(1000);
            MQDeleteQueue.Connect("TEST.AQ.UNITTEST", MQDeleteQueue.QueueType.ALIAS);
            MQDeleteQueue.Connect("TEST.AQ.UNITTEST2", MQDeleteQueue.QueueType.ALIAS);
            MQDeleteQueue.ProcessAll();*/
        }
    }
}
