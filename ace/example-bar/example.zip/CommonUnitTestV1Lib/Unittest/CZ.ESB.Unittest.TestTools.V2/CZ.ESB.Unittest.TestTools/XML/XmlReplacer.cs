﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace CZ.ESB.Unittest.TestTools.XML
{
    public class XmlReplacer
    {
        public static string Replace(string input)
        {
            Regex regex = new Regex("#DATE-\\((\\S*)\\)#");
            Match m = regex.Match(input);

            input = ValidateAndRemoveVariables(XDocument.Parse(input)).ToString();

            string dat = ReplaceDateValue(m, input);

            return dat;
        }

        private static string ReplaceDateValue(Match m, string input)
        {
            if (m.Length != 0)
            {
                input = input.Replace(m.Value, DateTime.Now.ToString(m.Groups[1].Value));

                m = m.NextMatch();

                return ReplaceDateValue(m, input);
            }

            return input;
        }

        public static XDocument ValidateAndRemoveVariables(XDocument message)
        {
            message = RemoveTrackingID(message);
            message = ValidateAndRemoveDatum(message, "verzendDatumTijd", "urn:cz:cdm:esb:0201");
            message = ValidateAndRemoveDatum(message, "verzendDatumTijd", "urn:cz:cdm:esb:0300");

            return message;
        }

        public static XDocument ValidateAndRemoveDatum(XDocument message, string elementName, string elementNamespace)
        {
            var element = message.Descendants(XName.Get(elementName, elementNamespace)).FirstOrDefault();

            if (element != null && !element.IsEmpty)
            {
                DateTime datum = DateTime.Parse(element.Value);

                TimeSpan timeSpan = TimeSpan.FromMinutes(1);
                DateTime rangeStart = DateTime.Now - timeSpan;
                DateTime rangeEnd = DateTime.Now + timeSpan;

                //Assert.IsTrue(rangeStart <= datum && rangeEnd >= datum, String.Format("Expected current datetime {0} for element {1} in message not in range {2}-{3}", datum, element.Name, rangeStart, rangeEnd));

                element.Value = "CURRENTTIME";
            }

            return message;
        }

        public static XDocument RemoveTrackingID(XDocument message)
        {
            var element = message.Descendants(XName.Get("trackingId", "urn:cz:cdm:esb:0201")).FirstOrDefault();

            if (element != null && !element.IsEmpty)
            {
                element.Value = "GUID";
            }

            return message;
        }


    }
}
