﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using CZ.ESB.Unittest.TestTools.FILE;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Org.XmlUnit;
using Org.XmlUnit.Builder;

namespace CZ.ESB.Unittest.TestTools.XML
{
    public class XmlHelper
    {
        public static void CompareAgainstFile(string xmlA, string fileName)
        {
            Compare(xmlA, Files.ReadStringFromFileName(fileName));
        }

        public static void Compare(string xmlA, string xmlB)
        {
            var myDiff = DiffBuilder.Compare(Input.FromString(XmlReplacer.Replace(xmlA)))
                .WithTest(Input.FromString(XmlReplacer.Replace(xmlB)))
                .CheckForSimilar()
                .IgnoreWhitespace()
                .IgnoreComments()
                .Build();

            Assert.IsFalse(myDiff.HasDifferences(), myDiff.ToString());
        }


    }
}
