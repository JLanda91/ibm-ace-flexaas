﻿using CZ.ESB.Unittest.TestTools.Base;
using System.Collections.Generic;
using System.Text;
using System.IO;
using IBM.WMQ;
using System.Diagnostics;
using CZ.ESB.Unittest.TestTools.Properties;

namespace CZ.ESB.Unittest.TestTools.MQ
{
    public class MQDeleteQueue
    {
        private MQQueueManager queueManager;
        private MQQueue queue;

        public enum QueueType
        {
            LOCAL,
            ALIAS
        }

        static public List<MQDeleteQueue> mqDeleteQueues = new List<MQDeleteQueue>();

        public string QueueManager { get; private set; }

        public string DeleteQueue { get; private set; }

        public QueueType TypeQueue { get; private set; }

        public static MQDeleteQueue Connect(string deleteQueue)
        {
            return Connect(null, deleteQueue, QueueType.LOCAL);
        }

        public static MQDeleteQueue Connect(string deleteQueue, QueueType typeQueue)
        {
            return Connect(null, deleteQueue, typeQueue);
        }

        public static MQDeleteQueue Connect(string queueManager, string deleteQueue, QueueType typeQueue)
        {
            MQDeleteQueue mqDeleteQueue = new MQDeleteQueue();
            if (queueManager == null)
            {
                mqDeleteQueue.QueueManager = GetQueueManager();
            }
            else
            {
                mqDeleteQueue.QueueManager = queueManager;
            }
            mqDeleteQueue.DeleteQueue = deleteQueue;
            mqDeleteQueue.TypeQueue = typeQueue;

            mqDeleteQueues.Add(mqDeleteQueue);

            return mqDeleteQueue;
        }

        public static void ProcessAll()
        {
            foreach (MQDeleteQueue mqDeleteQueue in mqDeleteQueues)
            {
                mqDeleteQueue.Process();
            }
        }

        public void Process()
        {
            if (TypeQueue != QueueType.ALIAS) {
                DeleteLocalQueue();
            }
            else { DeleteAliasQueue(); }
        }

        private void ConnectToMq()
        {
            queueManager = new MQQueueManager(QueueManager);
            queue = queueManager.AccessQueue(DeleteQueue, MQC.MQOO_INQUIRE);
        }


        private void DeleteLocalQueue()
        {
            string script = Resources.DeleteLocalQueue;
            const string fileName = "DeleteLocalQueue.bat";
            File.AppendAllText(fileName, script);
            string arguments = $"{QueueManager} {DeleteQueue}";
            //start a process and hook up the in/output
            var proces = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = fileName,
                    Arguments = arguments,
                    CreateNoWindow = false,
                    ErrorDialog = true,
                    RedirectStandardError = false,
                    RedirectStandardOutput = false,
                    UseShellExecute = true
                },
                EnableRaisingEvents = true
            };

            //store the errors in a stringbuilder
            var errorBuilder = new StringBuilder();
            proces.ErrorDataReceived += (sender, args) =>
            {
                if (args != null && args.Data != null)
                {
                    errorBuilder.AppendLine(args.Data);
                }
            };

            //store the errors in a stringbuilder
            var outputBuilder = new StringBuilder();
            proces.OutputDataReceived += (sender, args) =>
            {
                if (args != null && args.Data != null)
                {
                    outputBuilder.AppendLine(args.Data);
                }
            };

            proces.Start();
            proces.WaitForExit();

            OutputMessageReceived?.Invoke(outputBuilder.ToString());
            ErrorMessageReceived?.Invoke(errorBuilder.ToString());

            proces.Close();

            File.Delete(fileName);
        }

        private void DeleteAliasQueue()
        {
            string script = Resources.DeleteAliasQueue;
            const string fileName = "DeleteAliasQueue.bat";
            File.AppendAllText(fileName, AddLines(script));
            string arguments = $"{QueueManager} {DeleteQueue}";
            //start a process and hook up the in/output
            var proces = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = fileName,
                    Arguments = arguments,
                    CreateNoWindow = false,
                    ErrorDialog = true,
                    RedirectStandardError = false,
                    RedirectStandardOutput = false,
                    UseShellExecute = true
                },
                EnableRaisingEvents = true
            };

            //store the errors in a stringbuilder
            var errorBuilder = new StringBuilder();
            proces.ErrorDataReceived += (sender, args) =>
            {
                if (args != null && args.Data != null)
                {
                    errorBuilder.AppendLine(args.Data);
                }
            };

            //store the errors in a stringbuilder
            var outputBuilder = new StringBuilder();
            proces.OutputDataReceived += (sender, args) =>
            {
                if (args != null && args.Data != null)
                {
                    outputBuilder.AppendLine(args.Data);
                }
            };

            proces.Start();
            proces.WaitForExit();

            OutputMessageReceived?.Invoke(outputBuilder.ToString());
            ErrorMessageReceived?.Invoke(errorBuilder.ToString());

            proces.Close();

            File.Delete(fileName);
        }

        public static event OutputMessageReceivedHandler OutputMessageReceived;
        public static event ErrorMessageReceivedHandler ErrorMessageReceived;

        public delegate void ErrorMessageReceivedHandler(string message);
        public delegate void OutputMessageReceivedHandler(string message);

        private static string GetQueueManager()
        {
            return UnitTestHelper.ReadConfigurationSetting("QueueManager");
        }

        public static string AddLines(string msg)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(msg);
            if (pause)
            {
                sb.AppendLine("pause");
            }

            return sb.ToString();
        }

        public static bool pause { get; set; }
        /// <summary>
        /// Only run on VDI!
        /// </summary>
        public static void PauseAfterScript()
        {
            pause = true;
        }
    }
}
