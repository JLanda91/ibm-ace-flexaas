﻿namespace CZ.ESB.Unittest.TestTools.MQ
{
    public static partial class MQConstants
    {
        public const string UnitTestQueueManager = "IIB10QM";

        
    }
}
