﻿using CZ.ESB.Unittest.TestTools.Base;
using System.Collections.Generic;
using System.Text;
using System.IO;
using IBM.WMQ;
using System.Diagnostics;
using CZ.ESB.Unittest.TestTools.Properties;
using System;

namespace CZ.ESB.Unittest.TestTools.MQ
{
    public class MQNewTopic
    {
        private MQQueueManager queueManager;
  
        public string Persistancy { get; private set; }

        public string QueueManager { get; private set; }

        public string NewTopicName { get; private set; }
        public string NewTopicString { get; private set; }

        public static string GetPersistancyValues(bool persistant)
        {
            return persistant ? "YES" : "NO";
        }

        public static MQNewTopic Connect(string topicName, string topicString, bool persistant)
        {
            return Connect(null, topicName, topicString,  persistant);
        }

        public static MQNewTopic Connect(string queueManager, string topicName, string topicString, bool persistant)
        {
            MQNewTopic mqNewTopic = new MQNewTopic();

            mqNewTopic.CreateNewTopic(queueManager, topicName, topicString,  persistant);
            return mqNewTopic;
        }

        public void CreateNewTopic(string queueManager, string topicName, string topicString, bool persistant)
        {
            if (queueManager == null)
            {
                QueueManager = GetQueueManager();
            }
            else
            {
                QueueManager = queueManager;
            }

 
            NewTopicName = topicName;
            NewTopicString = topicString;
            Persistancy = GetPersistancyValues(persistant);
            string script = Resources.CreateTopic;
            const string fileName = "CreateTopic.bat";
            File.AppendAllText(fileName, AddLines(script));
            string arguments = $"{QueueManager} {NewTopicName} {NewTopicString} {Persistancy}";
            //start a process and hook up the in/output
            var proces = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = fileName,
                    Arguments = arguments,
                    CreateNoWindow = false,
                    ErrorDialog = true,
                    RedirectStandardError = false,
                    RedirectStandardOutput = false,
                    UseShellExecute = true
                },
                EnableRaisingEvents = true
            };

            //store the errors in a stringbuilder
            var errorBuilder = new StringBuilder();
            proces.ErrorDataReceived += (sender, args) =>
            {
                if (args != null && args.Data != null)
                {
                    errorBuilder.AppendLine(args.Data);
                }
            };

            //store the errors in a stringbuilder
            var outputBuilder = new StringBuilder();
            proces.OutputDataReceived += (sender, args) =>
            {
                if (args != null && args.Data != null)
                {
                    outputBuilder.AppendLine(args.Data);
                }
            };

            proces.Start();
            proces.WaitForExit();

            OutputMessageReceived?.Invoke(outputBuilder.ToString());
            ErrorMessageReceived?.Invoke(errorBuilder.ToString());

            proces.Close();

            File.Delete(fileName);
        }

        public static event OutputMessageReceivedHandler OutputMessageReceived ;
        public static event ErrorMessageReceivedHandler ErrorMessageReceived ;

        public delegate void ErrorMessageReceivedHandler(string message);
        public delegate void OutputMessageReceivedHandler(string message);

        private static string GetQueueManager()
        {
            return UnitTestHelper.ReadConfigurationSetting("QueueManager");
        }


        public static string AddLines(string msg)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(msg);
            if (pause)
            {
                sb.AppendLine("pause");
            }

            return sb.ToString();
        }

        public static bool pause { get; set; }
        /// <summary>
        /// Only run on VDI!
        /// </summary>
        public static void PauseAfterScript()
        {
            pause = true;
        }
    }
}
