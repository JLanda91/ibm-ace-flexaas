﻿using IBM.WMQ;

namespace CZ.ESB.Unittest.TestTools.MQ
{
    public class MQMessageHelper
    {
        public static string ReadMessageString(MQMessage message)
        {
            return message.ReadString(message.MessageLength);
        }

        public static bool IsMessagePersistent(MQMessage message)
        {
            return message.Persistence == MQC.MQPER_PERSISTENT;
        }
    }
}
