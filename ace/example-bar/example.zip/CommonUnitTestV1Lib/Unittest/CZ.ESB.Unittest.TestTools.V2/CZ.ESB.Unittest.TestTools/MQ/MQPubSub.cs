﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using IBM.WMQ;

namespace CZ.ESB.Unittest.TestTools.MQ
{
    public class MQPubSub
    {
        protected int openOptionsForGet = MQC.MQSO_CREATE | MQC.MQSO_FAIL_IF_QUIESCING | MQC.MQSO_MANAGED | MQC.MQSO_NON_DURABLE;
        protected int destType = MQC.MQOT_TOPIC;

        protected MQConnect mqConnect;
        protected MQQueueManager queueManager;
        protected bool waitForAnswer;
        protected int currentReads;
        protected bool messageAvailable;
        
        public string QueueManager { get; private set; }

        public static T Connect<T>() where T : MQPubSub, new()
        {
            T mps = new T()
            {
                QueueManager = GetQueueManager(),

            };

            mps.queueManager = new MQQueueManager(mps.QueueManager);

            return mps;
        }

        private static string GetQueueManager()
        {
            string queueManager = ConfigurationManager.AppSettings["QueueManager.Local"];

            if (Environment.MachineName.ToLower().StartsWith("app"))
            {
                queueManager = ConfigurationManager.AppSettings[string.Format("QueueManager.{0}", Environment.MachineName)];
            }

            return queueManager;
        }

    }
}
