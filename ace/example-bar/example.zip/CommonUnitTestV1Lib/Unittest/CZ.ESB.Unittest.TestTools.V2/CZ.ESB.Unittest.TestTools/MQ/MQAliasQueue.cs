﻿using CZ.ESB.Unittest.TestTools.Base;
using System.Collections.Generic;
using System.Text;
using System.IO;
using IBM.WMQ;
using System.Diagnostics;
using CZ.ESB.Unittest.TestTools.Properties;
using System.Threading;

namespace CZ.ESB.Unittest.TestTools.MQ
{
    public class MQAliasQueue
    {
        private MQQueueManager queueManager;
        private MQQueue queue;

        static public List<MQAliasQueue> mqAliasQueues = new List<MQAliasQueue>();

        public string QueueManager { get; private set; }

        public string AliasQueue { get; private set; }

        public string BaseQueue { get; private set; }

        private string StoredBaseQueue { get; set; }

        public static MQAliasQueue Connect(string aliasQueue, string baseQueue)
        {
            return Connect(null, aliasQueue, baseQueue);
        }

        public static MQAliasQueue Connect(string queueManager, string aliasQueue, string baseQueue)
        {
            MQAliasQueue mqAliasQueue = new MQAliasQueue();
            if (queueManager == null)
            {
                mqAliasQueue.QueueManager = GetQueueManager();
            }
            else
            {
                mqAliasQueue.QueueManager = queueManager;
            }
            mqAliasQueue.AliasQueue = aliasQueue;
            mqAliasQueue.BaseQueue = baseQueue;
            mqAliasQueue.StoreBaseQueue();

            mqAliasQueues.Add(mqAliasQueue);

            return mqAliasQueue;
        }

        public static void ProcessAll()
        {
            foreach(MQAliasQueue mqAliasQueue in mqAliasQueues)
            {
                mqAliasQueue.Process();
            }
            // After changing queues, wait 15 seconds for IIB to pick up new base queues
            Thread.Sleep(15000);
        }

        public static void RestoreAll()
        {
            foreach (MQAliasQueue mqAliasQueue in mqAliasQueues)
            {
                mqAliasQueue.Restore();
            }
            // After changing queues, wait 15 seconds for IIB to pick up new base queues
            Thread.Sleep(15000);
        }

        private void ConnectToMq()
        {
            queueManager = new MQQueueManager(QueueManager);
            queue = queueManager.AccessQueue(AliasQueue, MQC.MQOO_INQUIRE);
        }

        public void Process()
        {
            SetBaseQueue(BaseQueue);
        }

        public void Restore()
        {
            SetBaseQueue(StoredBaseQueue);
        }

        private void SetBaseQueue(string baseQueueName)
        {
            string script = Resources.ChangeAliasQueue;
            const string fileName = "ChangeAliasQueue.bat";
            File.AppendAllText(fileName, AddLines(script));
            string arguments = $"{QueueManager} {AliasQueue} {baseQueueName}";
            //start a process and hook up the in/output
            var proces = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = fileName,
                    Arguments = arguments,
                    CreateNoWindow = false,
                    ErrorDialog = true,
                    RedirectStandardError = false,
                    RedirectStandardOutput = false,
                    UseShellExecute = true
                },
                EnableRaisingEvents = true
            };
            
            //store the errors in a stringbuilder
            var errorBuilder = new StringBuilder();
            proces.ErrorDataReceived += (sender, args) =>
            {
                if (args != null && args.Data != null)
                {
                    errorBuilder.AppendLine(args.Data);
                }
            };

            //store the errors in a stringbuilder
            var outputBuilder = new StringBuilder();
            proces.OutputDataReceived += (sender, args) =>
            {
                if (args != null && args.Data != null)
                {
                    outputBuilder.AppendLine(args.Data);
                }
            };

            proces.Start();
            proces.WaitForExit();

            OutputMessageReceived?.Invoke(outputBuilder.ToString());
            ErrorMessageReceived?.Invoke(errorBuilder.ToString());

            proces.Close();

            File.Delete(fileName);
        }

        private void StoreBaseQueue()
        {
            ConnectToMq();
            StoredBaseQueue = queue.BaseQueueName;
        }

        public static event OutputMessageReceivedHandler OutputMessageReceived;
        public static event ErrorMessageReceivedHandler ErrorMessageReceived;

        public delegate void ErrorMessageReceivedHandler(string message);
        public delegate void OutputMessageReceivedHandler(string message);

        private static string GetQueueManager()
        {
            return UnitTestHelper.ReadConfigurationSetting("QueueManager");
        }

        public static string AddLines(string msg)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(msg);
            if (pause)
            {
                sb.AppendLine("pause");
            }

            return sb.ToString();
        }

        public static bool pause { get; set; }
        /// <summary>
        /// Only run on VDI!
        /// </summary>
        public static void PauseAfterScript()
        {
            pause = true;
        }
    }
}
