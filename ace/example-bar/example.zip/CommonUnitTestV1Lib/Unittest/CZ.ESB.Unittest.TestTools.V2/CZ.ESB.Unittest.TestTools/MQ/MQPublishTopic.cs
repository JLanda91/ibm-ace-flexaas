﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IBM.WMQ;

namespace CZ.ESB.Unittest.TestTools.MQ
{
    public class MQPublishTopic : MQPubSub
    {

        public static void Publish(string topic, string data)
        {
            MQPublishTopic publishTopic = Connect<MQPublishTopic>();

            MQMessage message = new MQMessage();


            byte[] dataInBytes = Encoding.Default.GetBytes(data);

            dataInBytes = Encoding.Convert(Encoding.Default, Encoding.UTF8, dataInBytes);

            message = new MQMessage();
            message.MessageId = MessageIdGenerator.Generate().ValueAsBytes;
            message.CorrelationId = CorrelationIdGenerator.Generate().ValueAsBytes;
            message.Format = MQC.MQFMT_STRING;
            message.Write(dataInBytes);

            publishTopic.queueManager.Put(publishTopic.destType, null, null, topic, message);
        }
    }
}
