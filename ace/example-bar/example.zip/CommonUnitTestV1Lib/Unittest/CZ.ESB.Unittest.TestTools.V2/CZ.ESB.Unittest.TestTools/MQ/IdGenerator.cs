﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CZ.ESB.Unittest.TestTools.MQ
{
    public abstract class IdGenerator
    {
        private const string GuidSeperator = "-";

        public static Id Generate()
        {
            Id id = new Id();

            Guid guid = Guid.NewGuid();

            byte[] key = new byte[24];

            byte[] byteid = guid.ToByteArray();
            for (int i = 0; i < key.Length; i++)
            {
                if (i < byteid.Length)
                {
                    key[i] = byteid[i];
                }
                else
                {
                    key[i] = 0;
                }
            }

            id.ValueAsString = guid.ToString();
            id.ValueAsBytes = key;

            return id;
        }
    }
}
