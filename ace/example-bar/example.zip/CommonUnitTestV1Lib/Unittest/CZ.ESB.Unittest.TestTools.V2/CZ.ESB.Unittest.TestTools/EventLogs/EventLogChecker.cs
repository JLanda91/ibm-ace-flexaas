﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CZ.ESB.Unittest.TestTools.EventLogs
{
    public class EventLogChecker
    {
        /*
         * Calls the given operation and asserts that targetMessage is present in the eventlog, 
         * for the given source and namespace, within the timeframe of the operation's execution.
         */
        public static void callAndCheckLog(Action operation, string targetMessage, string flowNamespace, string source)
        {
            //All event logs for this test are generated after this line is executed
            System.DateTime startTime = System.DateTime.Now;
            System.Threading.Thread.Sleep(3000);

            //Perform the operations leading to event logs
            operation();

            //Check eventlogs after error
            EventLog appLog = new EventLog("Application");
            var entries = appLog.Entries.Cast<EventLogEntry>()
                         .Where(x => x.TimeGenerated >= startTime)
                         .Where(x => x.Source.Contains(source))
                         .Where(x => x.Message.Contains(flowNamespace))
                         .ToList();

            //Verify that the expected message is present
            bool messageFound = false;
            foreach (EventLogEntry entry in entries)
            {
                messageFound |= entry.Message.Contains(targetMessage);
            }
            Assert.IsTrue(messageFound);
        }

        public static void callAndCheckLog(Action operation, string targetMessage, string flowNamespace)
        {
            callAndCheckLog(operation, targetMessage, flowNamespace, "IBM Integration");
        }
    }
}
