﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using CZ.ESB.Unittest.TestTools.Base;
using System.Diagnostics;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CZ.ESB.Unittest.TestTools.SecureStore
{
    public class SecureStoreWriter
    {
        private static string GetSecureStoreFolder()
        {
            return UnitTestHelper.ReadConfigurationSetting("SecureStoreFolder");
        }

        private static string GetDefaultCertificateName()
        {
            return UnitTestHelper.ReadConfigurationSetting("SecureStoreCertificate");
        }

        public static void StoreEncryptedValue(string service, string key, string value)
        {
            StoreEncryptedValue(GetDefaultCertificateName(), service, key, value);
        }

        public static void StoreEncryptedValue(string certificateName, string service, string key, string value)
        {
            string filePath = GetSecureStoreFolder();
            string fileName = "CZ.ESB.Common.SecureConfigReader.Writer.exe";
            string arguments = $"{certificateName} {service} {key} {value}";
            //start a process and hook up the in/output
            using (var proces = new Process()
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = String.Concat(filePath, "/", fileName),
                    Arguments = arguments,
                    CreateNoWindow = false,
                    ErrorDialog = true,
                    RedirectStandardError = false,
                    RedirectStandardOutput = false,
                    UseShellExecute = true
                },
                EnableRaisingEvents = true
            })
            {

                //store the errors in a stringbuilder
                var errorBuilder = new StringBuilder();
                proces.ErrorDataReceived += (sender, args) =>
                {
                    if (args != null && args.Data != null)
                    {
                        errorBuilder.AppendLine(args.Data);
                    }
                };

                //store the errors in a stringbuilder
                var outputBuilder = new StringBuilder();
                proces.OutputDataReceived += (sender, args) =>
                {
                    if (args != null && args.Data != null)
                    {
                        outputBuilder.AppendLine(args.Data);
                    }
                };

                proces.Start();
                proces.WaitForExit();
                Assert.AreEqual(0, proces.ExitCode, "Failed to store in secure store");
            }
        }
    }
}
