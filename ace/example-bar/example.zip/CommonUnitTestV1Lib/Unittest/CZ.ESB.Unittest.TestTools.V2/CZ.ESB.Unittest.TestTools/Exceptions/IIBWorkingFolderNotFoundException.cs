﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CZ.ESB.Unittest.TestTools.Exceptions
{
    public class IIBWorkingFolderNotFoundException :Exception
    {
        public override string Message
        {
            get { return "IIB Root Working Folder was not found (mqsifilenodesrootdirectory)"; }
        }
    }
}
