﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using CZ.ESB.Unittest.TestTools.SOAP;

namespace CZ.ESB.Unittest.TestTools.HTTP
{
    public class HTTPStubRequestParser
    {
        public static HTTPStubRequest Parse(string request)
        {
            HTTPStubRequest requestObject = new HTTPStubRequest();

            StringBuilder msg = new StringBuilder();

            bool startTagHasBeenFound = false;

            string[] data = request.Split('\r');
            foreach (string datarow in data)
            {
                string localDatarow = datarow.Replace("\n", string.Empty);
                if (localDatarow.StartsWith("X-Original-HTTP-Command"))
                {
                    requestObject.PostUrl = localDatarow;
                }
                else if (localDatarow.StartsWith("X-Query-String"))
                {
                    requestObject.PostUrl = localDatarow.Split(':')[1].Trim();
                }
                else if (localDatarow.Split(':').Length == 2 && !startTagHasBeenFound)
                {
                    if (requestObject.Headers == null)
                    {
                        requestObject.Headers = new Dictionary<string, string>();
                    }
                    string[] header = localDatarow.Split(':');
                    var list = header.ToList();
                    list.RemoveAt(0);
                    requestObject.Headers.Add(header[0], string.Join(":", list).Trim());
                }
                else if (!startTagHasBeenFound && localDatarow.Equals(string.Empty))
                {
                    startTagHasBeenFound = true;
                }
                else if (startTagHasBeenFound)
                {
                    msg.AppendLine(localDatarow);
                }
            }

            requestObject.Message = msg.ToString().Trim();

            return requestObject;
        }
    }
}
