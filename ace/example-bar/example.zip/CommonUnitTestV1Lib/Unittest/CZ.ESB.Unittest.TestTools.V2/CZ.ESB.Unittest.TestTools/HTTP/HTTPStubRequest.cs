﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace CZ.ESB.Unittest.TestTools.HTTP
{
    public class HTTPStubRequest
    {
        public Dictionary<string, string> Headers { get; set; }
        public string Message { get; set; }
        public string PostUrl { get; set; }

        public string QueryString { get; set; }

        
    }
}
