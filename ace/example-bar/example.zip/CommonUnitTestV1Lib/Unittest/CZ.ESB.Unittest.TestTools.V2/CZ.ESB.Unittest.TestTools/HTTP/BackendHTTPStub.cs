﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using CZ.ESB.Unittest.TestTools.MQ;
using System.ServiceModel;
using System.ServiceModel.Channels;
using IBM.WMQ;

namespace CZ.ESB.Unittest.TestTools.HTTP
{
    public class BackendHTTPStub : IDisposable
    {
        private Id messageId;

        private int pollingInterval = 100;
        private int pollingAttempts = 100;
        private MQMessage content = null;

        private int statusCode = 200;

        private string contentType = null;

        public BackendHTTPStub()
        {

            messageId = MessageIdGenerator.Generate();
        }

        public BackendHTTPStub ChangePollingInterval(int ms)
        {
            pollingInterval = ms;
            return this;
        }

        public BackendHTTPStub ChangePollingAttempts(int attempts)
        {
            pollingAttempts = attempts;
            return this;
        }

        public BackendHTTPStub ChangeStatusCode(int httpStatusCode)
        {
            statusCode = httpStatusCode;
            return this;
        }

        public BackendHTTPStub ChangeContentType(string httpContentType)
        {
            contentType = httpContentType;
            return this;
        }

        private string PrepareMessage(string msg)
        {
            msg = this.ParseHTTPOptions() + msg;
            return msg;
        }

        private string ParseHTTPOptions()
        {
            // Option1=Value1|Option2=Value2|...
            return "<CZHTTPStubOptions>" +
                   "ReplyStatusCode=" + this.statusCode + "|" +
                   "ContentType=" + this.contentType +
                   "</CZHTTPStubOptions>";
        }

        public BackendHTTPStub AnswerWith(string msg)
        {
            MQConnect requestQueue =
                MQConnect.Connect(MQ.MQConstants.UnitTestQueueManager, MQConstants.MQQueue.HTTPRequestQueue);
            requestQueue.ChangePollingAttempts(pollingAttempts);
            requestQueue.ChangePollingInterval(pollingInterval);

            content = requestQueue.Get(true);

            MQConnect replyQueue =
                MQConnect.Connect(MQ.MQConstants.UnitTestQueueManager, MQConstants.MQQueue.HTTPReplyQueue);

            replyQueue.SetMessageId(messageId.ValueAsBytes);
            replyQueue.SetCorrelationId(content.MessageId);
            replyQueue.SendMessage(this.PrepareMessage(msg));

            return this;
        }

        public BackendHTTPStub AnswerWithBytes(byte[] data)
        {
            MQConnect requestQueue =
                MQConnect.Connect(MQ.MQConstants.UnitTestQueueManager, MQConstants.MQQueue.HTTPRequestQueue);

            requestQueue.ChangePollingAttempts(pollingAttempts);
            requestQueue.ChangePollingInterval(pollingInterval);

            content = requestQueue.Get(true);

            MQConnect replyQueue =
                MQConnect.Connect(MQ.MQConstants.UnitTestQueueManager, MQConstants.MQQueue.HTTPReplyQueue);
            replyQueue.SetMessageId(messageId.ValueAsBytes);
            replyQueue.SetCorrelationId(content.MessageId);
            replyQueue.SendMessage(data);

            return this;
        }

        public BackendHTTPStub AnswerWithDynamicString(Func<HTTPStubRequest, string> decision)
        {
            MQConnect requestQueue =
                MQConnect.Connect(MQ.MQConstants.UnitTestQueueManager, MQConstants.MQQueue.HTTPRequestQueue);

            requestQueue.ChangePollingAttempts(pollingAttempts);
            requestQueue.ChangePollingInterval(pollingInterval);

            content = requestQueue.Get(true);

            MQConnect replyQueue =
                MQConnect.Connect(MQ.MQConstants.UnitTestQueueManager, MQConstants.MQQueue.HTTPReplyQueue);
            replyQueue.SetMessageId(messageId.ValueAsBytes);
            replyQueue.SetCorrelationId(content.MessageId);
            replyQueue.SendMessage(this.PrepareMessage(decision(GetRequestMessage())));

            return this;
        }

        public BackendHTTPStub AnswerWithStatuscode(int httpstatuscode)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("<czunittesthttpcode>{0}</czunittesthttpcode>", httpstatuscode);

            return AnswerWith(sb.ToString());
        }

        public static void Clean()
        { 
            MQConnect.Clean(MQ.MQConstants.UnitTestQueueManager, MQConstants.MQQueue.HTTPRequestQueue);
            MQConnect.Clean(MQ.MQConstants.UnitTestQueueManager, MQConstants.MQQueue.HTTPReplyQueue);
        }

        public HTTPStubRequest GetRequestMessage()
        {
            return HTTPStubRequestParser.Parse(content.ReadString(content.MessageLength));
        }

        public void Dispose()
        {
        }
    }
}
