﻿namespace CZ.ESB.Unittest.TestTools.HTTP
{
    public static partial class MQConstants
    {
        public static partial class MQQueue
        {
            public const string HTTPReplyQueue = "TEST.STUB.HTTP.RPLY.LQ";
            public const string HTTPRequestQueue = "TEST.STUB.HTTP.RQST.LQ";
        }
    }
}
