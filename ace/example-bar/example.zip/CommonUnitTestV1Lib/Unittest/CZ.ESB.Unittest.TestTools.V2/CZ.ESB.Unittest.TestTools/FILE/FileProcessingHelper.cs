﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CZ.ESB.Unittest.TestTools.FILE
{
    public class FileProcessingHelper
    {
        private string flowApplicationName;
        public FileProcessingHelper(string flowApplicationName)
        {
            IIBWorkingFolder.Initialize();
            this.flowApplicationName = flowApplicationName;
        }

        public string GetWorkingFolder()
        {
            string path = Path.Combine(IIBWorkingFolder.Folder, flowApplicationName);

            CheckIfPathExists(path);

            return path;
        }

        public static void Clean(string flowApplicationName)
        {
            FileProcessingHelper helper = new FileProcessingHelper(flowApplicationName);
            foreach (var f in Directory.GetFiles(helper.GetWorkingFolder()))
            {
                File.Delete(f);
            }
            foreach (var f in helper.GetFilesArchiveDirectory())
            {
                File.Delete(f);
            }
            foreach (var f in helper.GetFilesTransitDirectory())
            {
                File.Delete(f);
            }
            foreach (var f in helper.GetFilesBackoutDirectory())
            {
                File.Delete(f);
            }
        }

        public void CopyFileToWorkingFolder(string fileName)
        {
            File.Copy(fileName, Path.Combine(GetWorkingFolder(), new FileInfo(fileName).Name));
        }

        public string[] GetFilesArchiveDirectory()
        {
            string path = Path.Combine(GetWorkingFolder(), "mqsiarchive");
            CheckIfPathExists(path);
            return Directory.GetFiles(path);
        }

        public string[] GetFilesTransitDirectory()
        {
            string path = Path.Combine(GetWorkingFolder(), "mqsitransitin");
            CheckIfPathExists(path);
            return Directory.GetFiles(path);
        }

        public string[] GetFilesBackoutDirectory()
        {
            string path = Path.Combine(GetWorkingFolder(), "mqsibackout");
            CheckIfPathExists(path);
            return Directory.GetFiles(path);
        }

        private static void CheckIfPathExists(string path)
        {
            if (!Directory.Exists(path))
            {
                throw new DirectoryNotFoundException(string.Format("IIB Working directory not found: " + path));
            }
        }
    }
}
