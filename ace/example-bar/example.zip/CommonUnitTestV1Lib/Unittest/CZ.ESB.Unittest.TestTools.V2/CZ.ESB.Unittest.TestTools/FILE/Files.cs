﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using CZ.ESB.Unittest.TestTools.Base;
using CZ.ESB.Unittest.TestTools.Exceptions;

namespace CZ.ESB.Unittest.TestTools.FILE
{
    public class Files
    { 
        public static void Copy(string source, string destination)
        {
            if (!File.Exists(source))
            {
                throw new FileNotFoundException("File not found at source location", source);
            }
            if (File.Exists(destination))
            {
                throw new FileFoundException(destination);
            }

            File.Copy(source, destination, false);
        }

        public static void Move(string source, string destination)
        {
            if (!File.Exists(source))
            {
                throw new FileNotFoundException("File not found at source location", source);
            }
            if (File.Exists(destination))
            {
                throw new FileFoundException(destination);
            }

            File.Move(source, destination);
        }

        public static string ReadStringFromFileName(string fileName)
        {
            return File.ReadAllText(GetFullFilePath(fileName));
        }

        public static string GetFullFilePath(string fileName)
        {
            string path = UnitTestHelper.GetCurrentDirectory();

            return string.Format(@"{0}\{1}", path, fileName);
        }

        public static string ReadString(string fileName)
        {

            return File.ReadAllText(fileName);
        }

        public static byte[] ReadBytes(string fileName)
        {

            return File.ReadAllBytes(fileName);
        }

        public static FileProcessingHelper GetFileProcessingProgress(string flowApplicationName)
        {
            FileProcessingHelper f = new FileProcessingHelper(flowApplicationName);

            return f;
        }
    }

    
}
