﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace CZ.ESB.Unittest.TestTools.Base
{
    public class UnitTestHelper
    {
        public static string GetCurrentDirectory()
        {
            return Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
        }

        public static string GetNode()
        {
            return ReadConfigurationSetting("Node");
        }

        public static string GetQueueManager()
        {
            return ReadConfigurationSetting("QueueManager");
        }

        
        public static string ReadConfigurationSetting(string setting)
        {
            //We kijken eerst lokaal
            string settingName = string.Format("{0}.Local", setting);

            string content = ConfigurationManager.AppSettings[settingName];

            //Daarna of er een Remote variant is
            settingName = string.Format("{0}.Remote", setting);
            string contentRemote = ConfigurationManager.AppSettings[settingName];

            if (!string.IsNullOrEmpty(contentRemote) && Environment.MachineName.ToLower().StartsWith("app"))
            {
                content = contentRemote;
            }
            else if(Environment.MachineName.ToLower().StartsWith("app"))
            {
                //En anders of er een machine specifieke variant is
                settingName = string.Format("{0}.{1}", setting, Environment.MachineName);
                content = ConfigurationManager.AppSettings[settingName];
            }

            return content;
        }
   
    }
}
