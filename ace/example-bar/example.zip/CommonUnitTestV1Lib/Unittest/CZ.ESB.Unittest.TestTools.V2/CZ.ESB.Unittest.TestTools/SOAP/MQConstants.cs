﻿namespace CZ.ESB.Unittest.TestTools.SOAP
{
    public static partial class MQConstants
    {
        public static partial class MQQueue
        {
            public const string SOAPReplyQueue = "TEST.STUB.SOAP.RPLY.LQ";
            public const string SOAPRequestQueue = "TEST.STUB.SOAP.RQST.LQ";
            public const string SOAPRequestHeaderQueue = "TEST.STUB.SOAP.RQST.HDR.LQ";
        }
    }
}
