﻿using System.ServiceModel.Channels;
using System.ServiceModel.Description;
using System.ServiceModel.Dispatcher;

namespace CZ.ESB.Unittest.TestTools.SOAP
{
    /// <summary>
    /// Uitbreiding op Asset endpoint om doormiddel van <see cref="IClientMessageInspector"/> inspectie te kunnen doen op Asset response berichten.<br/>
    /// </summary>
    /// <seealso cref="IEndpointBehavior"/>
    internal class AssetEndPointBehavior : IEndpointBehavior
    {
        private IClientMessageInspector[] clientMessageInspectors;

        /// <summary>
        /// Creeer een instantie van <see cref="AssetEndPointBehavior"/> met gegeven lijst van <see cref="IClientMessageInspector"/>.
        /// </summary>
        /// <param name="clientMessageInspectors"><see cref="IClientMessageInspector"/> message inspectors die moeten worden toegevoegd.</param>
        public AssetEndPointBehavior(IClientMessageInspector[] clientMessageInspectors)
        {
            this.clientMessageInspectors = clientMessageInspectors;
        }

        /// <summary>
        /// Niet geimplementeerd.<br/>
        /// <seealso cref="IEndpointBehavior.AddBindingParameters(ServiceEndpoint, BindingParameterCollection)"/>
        /// </summary>
        public void AddBindingParameters(ServiceEndpoint endpoint, BindingParameterCollection bindingParameters)
        {
        }

        /// <summary>
        /// Voeg de gegeven lijst met <see cref="IClientMessageInspector"/> toe aan de lijst met client message inspectors.
        /// </summary>
        /// <seealso cref="IEndpointBehavior.ApplyClientBehavior(ServiceEndpoint, ClientRuntime)"/>
        public void ApplyClientBehavior(ServiceEndpoint endpoint, ClientRuntime clientRuntime)
        {
            foreach (var clientMessageInspector in this.clientMessageInspectors)
            {
                clientRuntime.ClientMessageInspectors.Add(clientMessageInspector);
            }
        }

        /// <summary>
        /// Niet geimplementeerd.<br/>
        /// <seealso cref="IEndpointBehavior.ApplyDispatchBehavior(ServiceEndpoint, EndpointDispatcher)"/>
        /// </summary>
        public void ApplyDispatchBehavior(ServiceEndpoint endpoint, EndpointDispatcher endpointDispatcher)
        {
        }

        /// <summary>
        /// Niet geimplementeerd.<br/>
        /// <seealso cref="IEndpointBehavior.Validate(ServiceEndpoint)"/>
        /// </summary>
        public void Validate(ServiceEndpoint endpoint)
        {
        }
    }
}
