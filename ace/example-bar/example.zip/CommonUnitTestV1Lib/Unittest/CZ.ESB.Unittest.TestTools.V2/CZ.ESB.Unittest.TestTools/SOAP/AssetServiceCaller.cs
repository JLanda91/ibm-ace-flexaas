﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel.Description;
using System.ServiceModel.Dispatcher;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using CZ.ESB.Unittest.TestTools.MQ;

namespace CZ.ESB.Unittest.TestTools.SOAP
{
    public class AssetServiceCaller
    {
        /// <summary>
        /// Call deze methode om een asset service aan te roepen met een unit test.
        /// </summary>
        /// <param name="webserviceCall">Methode om een webservice aan te roepen en te testen</param>
        /// <param name="systeemServiceInQueue">In queue voor de systeem service</param>
        /// <param name="systeemServiceResponse">Antwoord dat terug gegeven wordt als stub op de response queue</param>
        public static string Call(Action webserviceCall, string systeemServiceInQueue, string systeemServiceResponse)
        {
            string sysRequest = "";
            Parallel.Invoke(
                webserviceCall, 
                () => {
                    var mqMarsRequest = MQConnect.Connect(systeemServiceInQueue);
                    mqMarsRequest.ChangePollingAttempts(1000);
                    mqMarsRequest.ChangePollingInterval(100);
                    var marsrequest = mqMarsRequest.Get(true);
                    var mqMarsResponse = MQConnect.Connect(mqMarsRequest.ReplyToQueueManager, mqMarsRequest.ReplyToQueue);
                    mqMarsResponse.SetCorrelationId(marsrequest.CorrelationId);
                    mqMarsResponse.SendMessage(systeemServiceResponse);
                    sysRequest = marsrequest.ReadString(marsrequest.MessageLength);
                }
            );
            return sysRequest;
        }

        /// <summary>
        /// Roep deze methode aan een asset service aan te roepen met een unit test.
        /// </summary>
        /// <param name="webserviceCall">Methode om een webservice aan te roepen en te testen</param>
        /// <param name="systeemServiceInQueue">In queue voor de systeem service</param>
        /// <param name="systeemServiceResponse">Antwoord dat terug gegeven wordt als stub op de response queue</param>
        /// <returns>SOAP antwoord dat wordt teruggestuurd door de asset service.</returns>
        public static string Call(
            Action webserviceCall,
            string systeemServiceInQueue,
            string systeemServiceResponse,
            ServiceEndpoint client
        )
        {
            string soapBody = string.Empty;
            var manualResetEvent = new ManualResetEventSlim(false);
            EventHandler <SoapBodyReceivedEventArgs> soapBodyReceivedHandler = (object sender, SoapBodyReceivedEventArgs e) => {
                soapBody = e.SoapBody;
                manualResetEvent.Set();
            };
            var bodyClientMessageInspector = new SOAPBodyClientMessageInspector();
            bodyClientMessageInspector.SoapBodyReceived += soapBodyReceivedHandler;

            var assetEndPointBehavior = new AssetEndPointBehavior(new[] { bodyClientMessageInspector });
            client.EndpointBehaviors.Add(assetEndPointBehavior);
            Parallel.Invoke(
                webserviceCall,
                () => {
                    var mqMarsRequest = MQConnect.Connect(systeemServiceInQueue);
                    mqMarsRequest.ChangePollingAttempts(1000);
                    mqMarsRequest.ChangePollingInterval(100);
                    var marsrequest = mqMarsRequest.Get(true);
                    var mqMarsResponse = MQConnect.Connect(mqMarsRequest.ReplyToQueueManager, mqMarsRequest.ReplyToQueue);
                    mqMarsResponse.SetCorrelationId(marsrequest.CorrelationId);
                    mqMarsResponse.SendMessage(systeemServiceResponse);
                }
            );
            manualResetEvent.Wait();
            manualResetEvent.Dispose();
            bodyClientMessageInspector.SoapBodyReceived -= soapBodyReceivedHandler;
            return soapBody;
        }
    }
}
