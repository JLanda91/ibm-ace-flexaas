package nl.cz.esb.common.backendrtr.v1;

import com.ibm.broker.config.proxy.BrokerProxy;

public class BackendRouter {

	private static BrokerProxy bp;
	
	public static String getConfigProperty(String property) {
		try {
			if (bp == null) {
				bp = BrokerProxy.getLocalInstance();
				while(!bp.hasBeenPopulatedByBroker())
				{
					// Give up thread for other threads to process.
					Thread.sleep(50);
				}
			}
			String result = bp.getConfigurableServiceProperty(property);
			if (result.equals("")) {
				throw new BackendRouterException("Configurable Service property " + property + " not found or empty.");
			}
			bp.disconnect();
			return result;
		}
		catch(Exception e) {
			throw new BackendRouterException(e);
		}
	}

}
