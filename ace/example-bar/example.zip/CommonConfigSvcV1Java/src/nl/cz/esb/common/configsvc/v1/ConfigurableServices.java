package nl.cz.esb.common.configsvc.v1;

import java.util.Properties;
import java.util.Enumeration;

import com.ibm.broker.config.proxy.*;
import com.ibm.broker.plugin.MbElement;

public class ConfigurableServices {

	private static BrokerProxy bp;

	public static String getProperty(String property)
	{
		try
		{
			initBrokerProxy();
			return bp.getConfigurableServiceProperty(property);
		}
		catch (Exception e) {
			throw new ConfigurableServicesException(e);
		}
	}

	public static void getPropertyList(String configsvc, MbElement list)
	{
		try
		{
			initBrokerProxy();
			String part[] = configsvc.split("/", 2);
			ConfigurableService cs = bp.getConfigurableService(part[0], part[1]);
			Properties ps = cs.getProperties();
			Enumeration<?> e = ps.propertyNames();
			
			while (e.hasMoreElements())
			{
				String key = (String)e.nextElement();
				list.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, key, ps.getProperty(key));
			}
			bp.disconnect();
		}
		catch (Exception e) {
			throw new ConfigurableServicesException(e);
		}
	}
	
	private static synchronized void initBrokerProxy() throws Exception
	{
		//Connect only once!!!
		if(bp==null)
		{
			bp=BrokerProxy.getLocalInstance();
			while(!bp.hasBeenPopulatedByBroker())
			{
				// Give up thread for other threads to process.
				Thread.yield();
			}
		}	
	}
}
