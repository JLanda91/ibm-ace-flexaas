package nl.cz.esb.common.configsvc.v1;

public class ConfigurableServicesException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public ConfigurableServicesException() {
		super();
	}

	public ConfigurableServicesException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
	}

	public ConfigurableServicesException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	public ConfigurableServicesException(String arg0) {
		super(arg0);
	}

	public ConfigurableServicesException(Throwable arg0) {
		super(arg0);
	}

}
